const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,

  devServer: {
    client: {
      overlay: {
        errors: true,    // 只显示真实错误
        warnings: false, // 不显示警告
        runtimeErrors: false, // 可选：关闭运行时错误弹窗
      },
    },
  },
})
