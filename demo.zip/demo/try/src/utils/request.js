import axios from "axios";
import { ElMessage } from "element-plus";
import router from "@/router/index.js";

const request = axios.create({
    //baseURL: 'http://47.76.140.101:8088',
    baseURL: 'http://localhost:8088',
    timeout: 5000,
    withCredentials: true 
});

request.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    console.log('从 localStorage 获取的 Token:', token); 
    if (token) {
        config.headers['Authorization'] = `Bearer ${token}`; 
    }
    if (config.method!== 'delete') {
        config.headers['Content-Type'] = 'application/json;charset=utf-8';
    }
    return config;
}, error => {
    return Promise.reject(error);
});

/*
request.interceptors.request.use(config => {
  config.headers['Content-Type']='application/json;charset=utf-8';
  let user = JSON.parse(localStorage.getItem('user-info') || '{}');
  config.headers['token'] = user.token
  return config
},error=>{
    return Promise.reject(error)
});
*/

request.interceptors.response.use(
    response => {
        let res = response.data;
        if (typeof res == 'string') {
            res = res? JSON.parse(res) : res;
        }
        if(res.code == '401'){
            ELMessage.error(res.msg);
        }else{
            return res;
        }
    },
    error => {
        if (error.response) {
            // 当 error.response 存在时，才访问 status 属性
            if (error.response.status === 404) {
                ElMessage.error('未找到请求接口');
            } else if (error.response.status === 500) {
                ElMessage.error('系统异常，请查看后端控制台报错');
            } else {
                console.error(error.message);
            }
        } else {
            // 当 error.response 不存在时，给出通用的网络请求失败提示
            console.error('网络请求失败:', error.message);
        }
        return Promise.reject(error);
    }
);

export default request;
