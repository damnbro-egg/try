<template>
  <div class="car-container">
    <div class="car-header">
      <div class="ad">
        <img src="../assets/images/ad.jpg" alt="ad">
      </div>
    </div>

    <div class="car-grid">
      <div v-for="car in carList" :key="car.id" class="car-card" @click="goToDetail(car.id)">
        <div class="car-image">
          <img :src="car.carPicture" :alt="car.name">
        </div>
        <div class="car-info">
          <h3 class="car-name">{{ car.name }}
            <span class="car-model">{{ car.model }}</span>
          </h3>
          <div class="car-tags">
            <span class="tag">{{ car.carType }}</span>
            <span class="tag">{{ car.powerType }}</span>
            <span class="tag">续航里程：{{ car.range }}km</span>
          </div>
          <div class="car-price">
            <span class="price-label">指导价：</span>
            <span class="price-value">{{ car.price }}万</span>
          </div>
          <el-button type="primary" class="detail-btn">查看详情</el-button>
        </div>
      </div>
    </div>

    <div class="pagination">
      <el-pagination
        layout="total, sizes, prev, pager, next, jumper"
        :page-sizes="[12, 24, 36, 48]"
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handlePageChange"
      />
    </div>
  </div>
</template>

<script>
import request from '@/utils/request';
import { useRouter } from 'vue-router';

export default {
  setup() {
    const router = useRouter();
    return {
      router
    };
  },
  data() {
    return {
      carList: [],
      currentPage: 1,
      pageSize: 12,
      total: 0
    }
  },
  created() {
    this.fetchCarList()
  },
  methods: {
    fetchCarList() {
      const params = {
        page: this.currentPage,
        size: this.pageSize
      }
      request.get("/car1/selectPage", {params})
        .then(response => {
          console.log('Response data:', response);
          this.carList = response.data.records;
          this.total = response.data.total;
        })
        .catch(error => {
          console.error('获取汽车列表失败:', error)
          this.$message.error('获取数据失败，请稍后重试')
        })
    },
    handleSizeChange(size) {
      this.pageSize = size
      this.currentPage = 1
      this.fetchCarList()
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchCarList()
    },
    goToDetail(id) {
      this.router.push({ path: '/car1', query: { id: id } });
    }
  }
}
</script>

<style scoped>
.car-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.car-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

.ad{
  width:1200px;
}

.ad img{
  width:100%;
  border-radius: 20px;
}

.car-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.car-card {
  background: rgb(255, 255, 255);
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(201, 198, 198, 0.1);
  transition: transform 0.3s;
  cursor: pointer;
}

.car-card:hover {
  transform: translateY(-5px);
}

.car-image {
  height: 200px;
  overflow: hidden;
}

.car-image img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.car-info {
  padding: 15px;
}

.car-name {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 8px;
}

.car-model {
  color: #666;
  font-size: 14px;
  margin-bottom: 12px;
  margin-left: 20px;
}

.car-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
}

.tag {
  background: #f9f9fa;
  color: #000;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.car-price {
  display: flex;
  align-items: baseline;
  margin-bottom: 15px;
}

.price-label {
  color: #999;
  font-size: 14px;
  margin-right: 8px;
}

.price-value {
  color: #f56c6c;
  font-size: 14px;
  font-weight: bold;
}

.detail-btn {
  width: 100%;
  background: #ffe14d;
  border:1px solid #ffe14d;
  color: #000;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-bottom:30px;
}
</style>