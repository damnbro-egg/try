<template>
    <div class="blog-detail">
        <div class="blog-container">
            <!-- 文章头部 -->
            <div class="article-header">
                <h1 class="article-title">{{ blog.title }}</h1>
                <div class="article-meta">
                    <div class="article-stats">
                        <span class="stat-item">
                            <i class="fa fa-eye"></i>
                            {{ blog.readCount }} 阅读
                        </span>
                        <span class="stat-item">
                            <i class="fa fa-clock-o"></i>
                            {{ blog.date }}
                        </span>
                    </div>
                </div>
            </div>

            <!-- 文章内容 -->
            <div class="article-content">
                <div class="article-body" v-html="blog.content"></div>
            </div>

            <!-- 文章底部 -->
            <div class="article-footer">
                <div class="article-tags">
                    <el-tag v-for="tag in JSON.parse(blog.tags || '[]')" 
                           :key="tag" 
                           size="small"
                           effect="plain">{{ tag }}</el-tag>
                </div>
                <div class="article-actions">
                    <div class="action-item" :class="{'liked': isLiked}" @click="toggleLike">
                        <i class="fa fa-thumbs-up" :style="{ color: isLiked ? '#67c23a' : '#86909c' }"></i>
                        <span :style="{ color: isLiked ? '#67c23a' : '#86909c' }">{{ likeCount }} 点赞</span>
                    </div>
                    <div class="action-item" :class="{'favorited': isFavorited}" @click="toggleFavorite">
                        <i class="fa fa-star" :style="{ color: isFavorited ? '#e6a23c' : '#86909c' }"></i>
                        <span :style="{ color: isFavorited ? '#e6a23c' : '#86909c' }">{{ favoriteCount }} 收藏</span>
                    </div>
                </div>
            </div>

            <!-- 评论区域 -->
            <div class="comment-section">
                <h3 class="comment-title">评论 ({{ commentList.length }})</h3>
                <!-- 评论输入框 -->
                <div class="comment-input">
                    <el-input
                        v-model="commentContent"
                        type="textarea"
                        :rows="3"
                        placeholder="写下你的评论..."
                        maxlength="200"
                        show-word-limit
                    />
                    <div class="comment-submit">
                        <el-button type="primary" @click="submitComment">发表评论</el-button>
                    </div>
                </div>

                <!-- 评论列表 -->
                <div class="comment-list">
                    <div v-if="commentList.length === 0" class="no-comments">
                        暂无评论，快来发表第一条评论吧！
                    </div>
                    <div v-else v-for="comment in commentList" :key="comment.id" class="comment-item">
                        <div class="comment-header">
                            <img :src="comment.author?.avatar || '/default-avatar.jpg'" class="comment-avatar" alt="avatar">
                            <div class="comment-info">
                                <span class="comment-author">{{ comment.author?.name || '匿名用户' }}</span>
                                <span class="comment-time">{{ comment.createDate }}</span>
                            </div>
                        </div>
                        <div class="comment-content">{{ comment.content }}</div>
                        
                        <!-- 回复列表 -->
                        <div v-if="comment.childrens && comment.childrens.length > 0" class="reply-list">
                            <!-- 显示前3条回复 -->
                            <div v-for="(reply, index) in comment.childrens.slice(0, expandedReplies.has(comment.id) ? undefined : 3)" 
                                 :key="reply.id" 
                                 class="reply-item">
                                <div class="reply-header">
                                    <img :src="reply.author?.avatar || '/default-avatar.jpg'" class="reply-avatar" alt="avatar">
                                    <div class="reply-info">
                                        <span class="reply-author">{{ reply.author?.name || '匿名用户' }}</span>
                                        <span v-if="reply.toUser" class="reply-to">
                                            回复
                                            <span class="to-user">@{{ reply.toUser?.name || '匿名用户' }}</span>
                                        </span>
                                        <span class="reply-time">{{ reply.createDate }}</span>
                                    </div>
                                </div>
                                <div class="reply-content">{{ reply.content }}</div>
                                
                                <!-- 二级评论的回复按钮 -->
                                <div class="reply-actions">
                                    <span class="reply-btn" @click="showReplyInput(reply, comment)">
                                        <i class="el-icon-chat-dot-round"></i>
                                        回复
                                    </span>
                                </div>

                                <!-- 二级评论的回复输入框 -->
                                <div v-if="activeReplyId === reply.id" class="reply-input">
                                    <el-input
                                        v-model="replyContents[reply.id]"
                                        type="textarea"
                                        :rows="2"
                                        :placeholder="'回复 @' + (reply.author?.name || '匿名用户')"
                                        maxlength="200"
                                        show-word-limit
                                    />
                                    <div class="reply-submit">
                                        <el-button size="small" @click="cancelReply(reply)">取消</el-button>
                                        <el-button type="primary" size="small" @click="submitReply(reply, comment)">回复</el-button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 查看更多按钮 -->
                            <div v-if="comment.childrens.length > 3 && !expandedReplies.has(comment.id)" 
                                 class="show-more-replies" 
                                 @click="expandReplies(comment.id)">
                                展开更多{{ comment.childrens.length - 3 }}条回复
                                <i class="el-icon-arrow-down"></i>
                            </div>
                            
                            <!-- 收起按钮 -->
                            <div v-if="expandedReplies.has(comment.id)" 
                                 class="show-more-replies" 
                                 @click="collapseReplies(comment.id)">
                                收起回复
                                <i class="el-icon-arrow-up"></i>
                            </div>
                        </div>

                        <!-- 回复按钮 -->
                        <div class="comment-actions">
                            <span class="reply-btn" @click="showReplyInput(comment)">
                                <i class="el-icon-chat-dot-round"></i>
                                回复
                            </span>
                        </div>

                        <!-- 回复输入框 -->
                        <div v-if="activeReplyId === comment.id" class="reply-input">
                            <el-input
                                v-model="replyContents[comment.id]"
                                type="textarea"
                                :rows="2"
                                placeholder="写下你的回复..."
                                maxlength="200"
                                show-word-limit
                            />
                            <div class="reply-submit">
                                <el-button size="small" @click="cancelReply(comment)">取消</el-button>
                                <el-button type="primary" size="small" @click="submitReply(comment)">回复</el-button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 右侧栏 -->
        <div class="right-sidebar">
            <!-- 合并作者信息和目录的卡片 -->
            <div class="sidebar-card">
                <!-- 作者信息 -->
                <div class="author-section">
                <div class="author-header">
                    <img :src="blog.avatar || '/default-avatar.jpg'" 
                         class="author-avatar" 
                         alt="avatar"
                         @error="handleAvatarError">
                    <div class="author-detail">
                        <div class="author-name">{{ blog.userName }}</div>
                        <div class="publish-time">
                            <i class="fa fa-clock-o"></i>
                            {{ blog.date }}
                        </div>
                    </div>
                </div>
            </div>

            <!-- 目录 -->
                <div class="toc-section">
                <div class="toc-title">目录</div>
                <div class="toc-content">
                    <div v-for="(item, index) in tocList" 
                         :key="index"
                         class="toc-item"
                         :class="{'toc-item-active': currentHeading === item.id}"
                         @click="scrollToHeading(item.id)">
                        {{ item.text }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import request from '@/utils/request';
import Vue from 'vue';

export default {
    data() {
        return {
            blog: {},
            tocList: [],
            currentHeading: '',
            userInfo: {},
            commentList: [],
            commentContent: '',
            activeReplyId: null,
            replyContents: {},
            expandedReplies: new Set(),
            // 初始状态设为 false 和 0
            isLiked: false,
            likeCount: 0,
            isFavorited: false,
            favoriteCount: 0
        }
    },
    mounted() {
        const blogId = this.$route.query.id;
        console.log('开始加载博客状态，博客ID:', blogId);
        
        // 加载博客详情
        this.loadBlogDetail();
        
        // 获取初始状态
        console.log('初始化点赞和收藏状态...');
        this.updateLikeStatus(blogId);
        this.updateFavoriteStatus(blogId);
        
        window.addEventListener('scroll', this.handleScroll);
        this.loadComments();
    },
    beforeUnmount() {
        window.removeEventListener('scroll', this.handleScroll);
    },
    methods: {
        loadBlogDetail() {
            const blogId = this.$route.query.id;
            request.get('/blog/selectPage', {
                params: {
                    page: 1,
                    size: 1,
                    id: blogId
                }
            }).then(res => {
                if (res.data && Array.isArray(res.data.records) && res.data.records.length > 0) {
                    const blogData = res.data.records[0];
                    this.blog = blogData;
                    this.loadUserInfo(this.blog.userId);
                    // 更新阅读量
                    this.updateReadCount();
                    // 在文章内容加载完成后初始化目录
                    this.$nextTick(() => {
                        this.initToc();
                    });
                }
            });
        },
        updateReadCount() {
            // 构造更新数据
            const updateData = {
                ...this.blog,
                readCount: (this.blog.readCount || 0) + 1
            };
            // 发送更新请求
            request.put('/blog/update', updateData).then(res => {
                if (res.code == 200) {
                    this.blog.readCount = updateData.readCount;
                }
            });
        },
        initToc() {
            // 清空之前的目录
            this.tocList = [];
            // 从文章内容中提取标题生成目录
            const content = document.querySelector('.article-body');
            if (content) {
                const headings = content.querySelectorAll('h1, h2, h3, h4, h5, h6');
                headings.forEach((heading, index) => {
                    const id = `heading-${index}`;
                    heading.id = id;
                    this.tocList.push({
                        id,
                        text: heading.textContent,
                        level: parseInt(heading.tagName[1])
                    });
                });
            }
        },
        handleScroll() {
            // 处理滚动，更新当前阅读的标题
            const headings = document.querySelectorAll('.article-body h1, .article-body h2, .article-body h3, .article-body h4, .article-body h5, .article-body h6');
            let currentHeading = '';
            
            headings.forEach(heading => {
                const rect = heading.getBoundingClientRect();
                if (rect.top <= 100) {
                    currentHeading = heading.id;
                }
            });
            
            this.currentHeading = currentHeading;
        },
        scrollToHeading(id) {
            const element = document.getElementById(id);
            if (element) {
                const offset = 80; // 设置一个偏移量，避免标题被顶部导航栏遮挡
                const elementPosition = element.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        },
        loadUserInfo(userId) {
            request.get('/user/selectById/' + userId).then(res => {
                if (res.data) {
                    this.blog.avatar = res.data.avatar || '/default-avatar.png';
                    console.log('用户头像URL:', this.blog.avatar);
                } else {
                    this.blog.avatar = '/default-avatar.png';
                }
            }).catch(error => {
                console.error('加载用户信息失败:', error);
                this.blog.avatar = '/default-avatar.png';
            });
        },
        loadComments() {
            const blogId = this.$route.query.id;
            console.log('正在加载评论，博客ID:', blogId);
            request.get(`/comment/article/${blogId}`).then(res => {
                console.log('评论数据响应:', res);
                if (res.code == 200 && res.data) {
                    // 确保评论按时间倒序排列
                    this.commentList = res.data.sort((a, b) => {
                        return b.createDate - a.createDate;
                    });
                    // 重置展开状态
                    this.expandedReplies.clear();
                    console.log('评论列表已更新:', this.commentList);
                } else {
                    console.error('加载评论失败:', res);
                    this.$message.error('加载评论失败');
                }
            }).catch(error => {
                console.error('加载评论出错:', error);
                this.$message.error('加载评论出错');
            });
        },
        submitComment() {
            if (!this.commentContent.trim()) {
                this.$message.warning('请输入评论内容');
                return;
            }

            const commentData = {
                articleId: parseInt(this.$route.query.id),  // 确保是数字类型
                content: this.commentContent,
                parent: null,
                toUserId: null
            };

            console.log('发送评论数据:', commentData);  // 添加日志

            request.post('/comment/create/change', commentData).then(res => {
                console.log('评论响应:', res);  // 添加日志
                if (res.code == 200) {
                    this.$message.success('评论成功');
                    this.commentContent = '';
                    this.loadComments();
                } else {
                    this.$message.error(res.msg || '评论失败');
                }
            }).catch(error => {
                console.error('评论出错:', error);  // 添加错误日志
                this.$message.error('评论失败');
            });
        },
        showReplyInput(reply, parentComment) {
            // 如果是二级评论的回复
            if (parentComment) {
                this.activeReplyId = reply.id;
                this.replyContents[reply.id] = '';
            } else {
                // 如果是一级评论的回复
                this.activeReplyId = reply.id;
                this.replyContents[reply.id] = '';
            }
        },
        cancelReply(reply) {
            this.activeReplyId = null;
            this.replyContents[reply.id] = '';
        },
        submitReply(reply, parentComment) {
            const content = this.replyContents[reply.id];
            if (!content?.trim()) {
                this.$message.warning('请输入回复内容');
                return;
            }

            const replyData = {
                articleId: parseInt(this.$route.query.id),
                content: content,
                parent: parentComment ? parseInt(parentComment.id) : parseInt(reply.id), // 父节点始终是一级评论
                toUserId: parseInt(reply.author.id) // 被回复的用户是当前评论的作者
            };

            console.log('发送回复数据:', replyData);

            request.post('/comment/create/change', replyData).then(res => {
                console.log('回复响应:', res);
                if (res.code == 200) {
                    this.$message.success('回复成功');
                    this.activeReplyId = null;
                    this.replyContents[reply.id] = '';
                    this.loadComments();
                } else {
                    this.$message.error(res.msg || '回复失败');
                }
            }).catch(error => {
                console.error('回复出错:', error);
                this.$message.error('回复失败');
            });
        },
        formatDate(timestamp) {
            if (!timestamp) return '';
            const date = new Date(timestamp * 1000);
            return date.toLocaleString('zh-CN', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });
        },
        expandReplies(commentId) {
            this.expandedReplies.add(commentId);
            // 强制更新视图
            this.$forceUpdate();
        },
        collapseReplies(commentId) {
            this.expandedReplies.delete(commentId);
            // 强制更新视图
            this.$forceUpdate();
        },
        handleAvatarError(e) {
            e.target.src = '/default-avatar.png';
        },
        updateLikeStatus(blogId) {
            if (!blogId) return;
            
            // 获取点赞状态
            request.get('/bloglikes/status', {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    this.isLiked = res.data;
                }
            }).catch(err => {
                console.error('获取点赞状态失败:', err);
            });

            // 获取点赞数量
            request.get('/bloglikes/count', {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    this.likeCount = res.data;
                }
            }).catch(err => {
                console.error('获取点赞数量失败:', err);
            });
        },
        updateFavoriteStatus(blogId) {
            if (!blogId) return;
            
            // 获取收藏状态
            request.get('/blogfavorites/status', {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    this.isFavorited = res.data;
                }
            }).catch(err => {
                console.error('获取收藏状态失败:', err);
            });

            // 获取收藏数量
            request.get('/blogfavorites/count', {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    this.favoriteCount = res.data;
                }
            }).catch(err => {
                console.error('获取收藏数量失败:', err);
            });
        },
        toggleLike() {
            const blogId = this.$route.query.id;
            if (!blogId) return;
            
            request.post('/bloglikes/toggle', null, {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    // 立即更新状态
                    this.updateLikeStatus(blogId);
                    this.$message.success(res.data);
                } else {
                    this.$message.error(res.msg || '操作失败');
                }
            }).catch(err => {
                console.error('点赞操作失败:', err);
                this.$message.error('操作失败');
            });
        },
        toggleFavorite() {
            const blogId = this.$route.query.id;
            if (!blogId) return;
            
            request.post('/blogfavorites/toggle', null, {
                params: { blogId: parseInt(blogId) }
            }).then(res => {
                if (res.code == 200) {
                    // 立即更新状态
                    this.updateFavoriteStatus(blogId);
                    this.$message.success(res.data);
                } else {
                    this.$message.error(res.msg || '操作失败');
                }
            }).catch(err => {
                console.error('收藏操作失败:', err);
                this.$message.error('操作失败');
            });
        }
    }
}
</script>

<style>
.blog-detail {
    display: flex;
    gap: 24px;
    max-width: 1200px;
    margin: 20px auto;
    padding: 0 20px;
}

.blog-container {
    flex: 1;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
    padding: 24px;
}

.article-header {
    margin-bottom: 24px;
}

.article-title {
    font-size: 28px;
    font-weight: 600;
    color: #1d2129;
    line-height: 1.4;
    margin-bottom: 16px;
}

.article-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.article-stats {
    display: flex;
    gap: 16px;
}

.stat-item {
    display: flex;
    align-items: center;
    gap: 4px;
    color: #86909c;
    font-size: 14px;
}

.article-content {
    margin-bottom: 24px;
}

.article-body {
    font-size: 16px;
    line-height: 1.8;
    color: #1d2129;
}

.article-body h1,
.article-body h2,
.article-body h3,
.article-body h4,
.article-body h5,
.article-body h6 {
    margin: 24px 0 16px;
    font-weight: 600;
    color: #1d2129;
}

.article-body h1 { font-size: 24px; }
.article-body h2 { font-size: 20px; }
.article-body h3 { font-size: 18px; }
.article-body h4 { font-size: 16px; }
.article-body h5 { font-size: 14px; }
.article-body h6 { font-size: 12px; }

.article-body p {
    margin-bottom: 16px;
}

.article-body img {
    max-width: 100%;
    border-radius: 8px;
    margin: 16px 0;
}

.article-footer {
    border-top: 1px solid #e5e6eb;
    padding-top: 24px;
}

.article-tags {
    display: flex;
    gap: 8px;
    margin-bottom: 24px;
}

.article-actions {
    display: flex;
    gap: 24px;
}

.action-item {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: all 0.3s;
    padding: 8px 16px;
    border-radius: 4px;
    color: #86909c;
}

.action-item:hover {
    background-color: #f2f3f5;
}

.action-item.liked {
    color: #67c23a;
}

.action-item.favorited {
    color: #e6a23c;
}

.action-item i {
    transition: color 0.3s;
}

.action-item span {
    transition: color 0.3s;
}

.right-sidebar {
    position: sticky;
    width: 240px;
    top: 70px;
    height: calc(100vh - 100px);
    overflow: hidden;
}

.sidebar-card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
    padding: 20px;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.author-section {
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e5e6eb;
    flex-shrink: 0;
}

.author-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 8px;
    background-color: #f7f8fa;
}

.author-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.author-detail {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.author-name {
    font-size: 16px;
    font-weight: 600;
    color: #1d2129;
}

.publish-time {
    font-size: 14px;
    color: #86909c;
    display: flex;
    align-items: center;
    gap: 4px;
}

.publish-time i {
    font-size: 14px;
}

.toc-section {
    flex: 1;
    overflow-y: auto;
    position: relative;
}

.toc-title {
    font-size: 16px;
    font-weight: 600;
    color: #1d2129;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #e5e6eb;
    position: sticky;
    top: 0;
    background-color: #fff;
    z-index: 1;
}

.toc-content {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding-top: 10px;
}

.toc-item {
    font-size: 14px;
    color: #4e5969;
    cursor: pointer;
    padding: 4px 0;
    transition: all 0.3s;
}

.toc-item:hover {
    color: #1e80ff;
}

.toc-item-active {
    color: #1e80ff;
    font-weight: 500;
}

/* 自定义滚动条样式 */
.toc-section::-webkit-scrollbar {
    width: 6px;
}

.toc-section::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}

.toc-section::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 3px;
}

.toc-section::-webkit-scrollbar-thumb:hover {
    background: #a8a8a8;
}

@media screen and (max-width: 1200px) {
    .right-sidebar {
        width: 100%;
        position: static;
        height: auto;
    }
    
    .sidebar-card {
        margin-top: 20px;
        height: auto;
    }
    
    .toc-section {
        max-height: none;
    }
}

/* 评论区域样式 */
.comment-section {
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #e5e6eb;
}

.comment-title {
    font-size: 20px;
    font-weight: 600;
    color: #1d2129;
    margin-bottom: 20px;
}

.comment-input {
    margin-bottom: 30px;
}

.comment-submit {
    margin-top: 10px;
    text-align: right;
}

.comment-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.comment-item {
    padding: 16px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.comment-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.comment-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.comment-info {
    display: flex;
    flex-direction: column;
}

.comment-author {
    font-weight: 500;
    color: #1d2129;
}

.comment-time {
    font-size: 12px;
    color: #86909c;
}

.comment-content {
    color: #1d2129;
    line-height: 1.6;
    margin-bottom: 12px;
    font-size: 14px;
}

.reply-list {
    margin-left: 52px;
    margin-top: 12px;
    border-left: 2px solid #e5e6eb;
    padding-left: 16px;
}

.reply-item {
    padding: 12px;
    background-color: #f7f8fa;
    border-radius: 6px;
    margin-bottom: 8px;
}

.reply-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.reply-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
}

.reply-info {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
}

.reply-author {
    font-weight: 500;
    color: #1d2129;
}

.reply-to {
    color: #86909c;
}

.to-user {
    color: #1e80ff;
    margin: 0 4px;
}

.reply-time {
    color: #86909c;
}

.reply-content {
    color: #1d2129;
    line-height: 1.6;
    font-size: 14px;
}

.comment-actions {
    margin-top: 8px;
    display: flex;
    align-items: center;
}

.reply-btn {
    color: #1e80ff;
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 4px;
}

.reply-btn:hover {
    color: #0c6fe3;
}

.reply-btn i {
    font-size: 16px;
}

.reply-input {
    margin-top: 12px;
    margin-left: 52px;
}

.reply-submit {
    margin-top: 8px;
    text-align: right;
}

.show-more-replies {
    color: #1e80ff;
    cursor: pointer;
    font-size: 14px;
    padding: 8px 0;
    display: flex;
    align-items: center;
    gap: 4px;
}

.show-more-replies:hover {
    color: #0c6fe3;
}

.show-more-replies i {
    font-size: 12px;
}

.no-comments {
    text-align: center;
    color: #86909c;
    padding: 20px;
    background-color: #f7f8fa;
    border-radius: 8px;
    margin-bottom: 20px;
}
</style>
