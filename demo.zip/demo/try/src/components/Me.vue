<template>
    <div class="container1">
        <div class="me-head">
            <img :src="data.user.avatar" class="avatar1"/>
            <div class="info0">
                <div class="info1">
                    <div>
                        {{data.user.name}}
                        <el-icon v-if="data.user.sex == 'male'"><Male/></el-icon>
                        <el-icon v-else><Female/></el-icon>
                    </div>
                    <el-button type="primary" @click="handleUpdate(data.user)">编辑个人信息</el-button>
                </div>
                <div class="info2">
                    <p>账号：{{data.user.username}}</p>
                    <p>电话：{{data.user.phone}}</p>
                    <p>邮件：{{data.user.email}}</p>
                    <p>生日：{{data.user.birth}}</p>
                    <p>个人简介：{{data.user.info}}</p>
                </div>
                <el-dialog title="编辑信息" v-model="data.formVisible" width="25%" 
                    :close-on-click-modal="false" destroy-on-close>
                    <el-form  ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
                    <el-form-item label="账号" prop="username">
                        <el-input v-model="data.form.username" placeholder="账号"/>
                    </el-form-item>
                    <el-form-item label="昵称" prop="name">
                        <el-input v-model="data.form.name" placeholder="昵称"/>
                    </el-form-item>
                    <el-form-item label="头像" prop="avatar">
                        <el-upload
                            class="avatar-uploader"
                        :action="'http://localhost:8088/files/upload'"
                        :headers="{ Authorization: 'Bearer ' + data.token }"
                        :on-success="handleFileSuccess"
                        list-type="picture"
                        >
                        <img v-if="data.form.avatar" :src="data.form.avatar" class="avatar" />
                        <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
                        </el-upload>
                    </el-form-item>
                    <el-form-item label="身份" prop="role">
                        <el-radio-group v-model="data.form.role">
                        <el-radio value="ADMIN" label="管理员" disabled></el-radio>
                        <el-radio value="USER" label="用户"></el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="性别" prop="sex">
                        <el-radio-group v-model="data.form.sex">
                        <el-radio value="male" label="男"></el-radio>
                        <el-radio value="female" label="女"></el-radio> 
                        </el-radio-group> 
                    </el-form-item>
                    <el-form-item label="电话" prop="phone">
                        <el-input v-model="data.form.phone" placeholder="电话"/>
                    </el-form-item>
                    <el-form-item label="邮件" prop="email">
                        <el-input v-model="data.form.email" placeholder="邮件"/>
                    </el-form-item>
                    <el-form-item label="个人简介" prop="info">
                        <el-input :rows="3" type="textarea" v-model="data.form.info" placeholder="个人简介"></el-input> 
                    </el-form-item>
                    <el-form-item label="生日" prop="birth">
                        <el-date-picker value-format="YYYY-MM-DD" format="YYYY-MM-DD" v-model="data.form.birth"></el-date-picker>
                    </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                    <el-button @click="data.formVisible = false">取 消</el-button>
                    <el-button type="primary" @click="save">保 存</el-button>
                    </div>
                </el-dialog>
            </div>
        </div>

        <!-- 添加标签页 -->
        <div class="tabs-container">
            <el-tabs v-model="data.activeTab">
                <el-tab-pane label="我的博客" name="blogs">
                    <div class="blog-list">
                        <div v-for="blog in data.blogs" :key="blog.id" class="blog-item" @click="goToBlog(blog.id)">
                            <div class="blog-cover">
                                <img :src="blog.cover" alt="封面">
                            </div>
                            <div class="blog-info">
                                <h3>{{ blog.title }}</h3>
                                <p class="blog-desc">{{ blog.descr }}</p>
                                <div class="blog-meta">
                                    <span>{{ formatDate(blog.createDate) }}</span>
                                    <span>{{ blog.viewCount }} 阅读</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <el-pagination
                        v-model:current-page="data.blogPage"
                        v-model:page-size="data.blogSize"
                        :page-sizes="[6, 12, 18, 24]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="data.blogTotal"
                        @size-change="handleBlogSizeChange"
                        @current-change="handleBlogPageChange"
                    />
                </el-tab-pane>

                <el-tab-pane label="我的评论" name="comments">
                    <div class="comment-list">
                        <div v-for="comment in data.comments" :key="comment.id" class="comment-item">
                            <div class="comment-content">
                                <p>{{ comment.content }}</p>
                                <div class="comment-meta">
                                    <span>发布于 {{ formatDate(comment.createDate) }}</span>
                                    <span class="article-link" @click="goToBlog(comment.articleId)">
                                        文章：{{ comment.articleTitle || '加载中...' }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <el-pagination
                        v-model:current-page="data.commentPage"
                        v-model:page-size="data.commentSize"
                        :page-sizes="[6, 12, 18, 24]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="data.commentTotal"
                        @size-change="handleCommentSizeChange"
                        @current-change="handleCommentPageChange"
                    />
                </el-tab-pane>

                <el-tab-pane label="回复我的" name="replies">
                    <div class="comment-list">
                        <div v-for="reply in data.replies" :key="reply.id" class="comment-item">
                            <div class="comment-header">
                                <img :src="reply.author?.avatar || '/default-avatar.jpg'" class="comment-avatar" alt="avatar">
                                <div class="comment-info">
                                    <span class="comment-author">{{ reply.author?.name || '匿名用户' }}</span>
                                </div>
                            </div>
                            <div class="comment-content">
                                <p>{{ reply.content }}</p>
                                <div class="comment-meta">
                                    <span>发布于 {{ formatDate(reply.createDate) }}</span>
                                    <span class="article-link" @click="goToBlog(reply.articleId)">
                                        文章：{{ reply.articleTitle || '加载中...' }}
                                    </span>
                                </div>
                            </div>
                            <!-- 添加回复按钮和输入框 -->
                            <div class="comment-actions">
                                <span class="reply-btn" @click="showReplyInput(reply)">
                                    <i class="el-icon-chat-dot-round"></i>
                                    回复
                                </span>
                            </div>
                            <!-- 回复输入框 -->
                            <div v-if="data.activeReplyId === reply.id" class="reply-input">
                                <el-input
                                    v-model="data.replyContents[reply.id]"
                                    type="textarea"
                                    :rows="2"
                                    :placeholder="'回复 @' + (reply.author?.name || '匿名用户')"
                                    maxlength="200"
                                    show-word-limit
                                />
                                <div class="reply-submit">
                                    <el-button size="small" @click="cancelReply(reply)">取消</el-button>
                                    <el-button type="primary" size="small" @click="submitReply(reply)">回复</el-button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <el-pagination
                        v-model:current-page="data.replyPage"
                        v-model:page-size="data.replySize"
                        :page-sizes="[6, 12, 18, 24]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="data.replyTotal"
                        @size-change="handleReplySizeChange"
                        @current-change="handleReplyPageChange"
                    />
                </el-tab-pane>

                <el-tab-pane label="我的收藏" name="favorites">
                    <div class="favorite-list">
                        <div v-for="blog in data.favorites" :key="blog.id" class="favorite-item" @click="goToBlog(blog.id)">
                            <div class="favorite-cover">
                                <img :src="blog.cover" alt="封面">
                            </div>
                            <div class="favorite-info">
                                <h3>{{ blog.title }}</h3>
                                <p class="favorite-desc">{{ blog.descr }}</p>
                                <div class="favorite-meta">
                                    <span>发布于 {{ formatDate(blog.date) }}</span>
                                    <span>{{ blog.readCount }} 阅读</span>
                                    <el-tag size="small" v-if="blog.categoryName">{{ blog.categoryName }}</el-tag>
                                    <el-tag size="small" v-for="tag in JSON.parse(blog.tags || '[]')" :key="tag" style="margin-left: 5px">{{ tag }}</el-tag>
                                </div>
                            </div>
                        </div>
                    </div>
                    <el-pagination
                        v-model:current-page="data.favoritePage"
                        v-model:page-size="data.favoriteSize"
                        :page-sizes="[6, 12, 18, 24]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="data.favoriteTotal"
                        @size-change="handleFavoriteSizeChange"
                        @current-change="handleFavoritePageChange"
                    />
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script setup>
import {reactive,ref, onMounted} from 'vue';
import {Search, Refresh, Edit, Delete, Female, Male} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';
import { jwtDecode } from 'jwt-decode';
import { useRouter } from 'vue-router';

const router = useRouter();
const data = reactive({
    formVisible:false,
    token:jwtDecode(localStorage.getItem('token'))||'{}', 
    user:{},
    activeTab: 'blogs',
    // 博客相关数据
    blogs: [],
    blogPage: 1,
    blogSize: 6,
    blogTotal: 0,
    // 评论相关数据
    comments: [],
    commentPage: 1,
    commentSize: 6,
    commentTotal: 0,
    // 回复评论数据
    replies: [],
    replyPage: 1,
    replySize: 6,
    replyTotal: 0,
    // 回复相关数据
    activeReplyId: null,
    replyContents: {},
    // 收藏相关数据
    favorites: [],
    favoritePage: 1,
    favoriteSize: 6,
    favoriteTotal: 0,
});

const load = () => {
    request.get('/user/selectById/'+data.token.claims.id).then(res=>{
        console.log(res.data);
        data.user = res.data;
    })
}

// 加载博客列表
const loadBlogs = () => {
    console.log('开始加载用户博客列表，当前页码:', data.blogPage, '每页数量:', data.blogSize);
    request.get('/blog/selectPage2', {
        params: {
            page: data.blogPage,
            size: data.blogSize
        }
    }).then(res => {
        console.log('博客列表API响应:', res);
        if (res.code === "200") {
            const pageData = res.data;
            console.log('分页数据:', {
                records: pageData.records,
                total: pageData.total,
                size: pageData.size,
                current: pageData.current,
                pages: pageData.pages
            });
            
            // 处理每条博客记录
            pageData.records.forEach(blog => {
                console.log('博客详情:', {
                    id: blog.id,
                    title: blog.title,
                    descr: blog.descr,
                    cover: blog.cover,
                    readCount: blog.readCount,
                    date: blog.date,
                    tags: blog.tags,
                    categoryName: blog.categoryName
                });
            });

            data.blogs = pageData.records;
            data.blogTotal = pageData.total;
        } else {
            console.error('获取博客列表失败:', res.msg || '未知错误');
            ElMessage.error('获取博客列表失败: ' + (res.msg || '未知错误'));
        }
    }).catch(error => {
        console.error('加载博客列表出错:', error);
        ElMessage.error('加载博客列表出错: ' + (error.message || '未知错误'));
    });
};

// 加载评论列表
const loadComments = () => {
    request.get('/comment/selectPage', {
        params: {
            page: data.commentPage,
            size: data.commentSize,
            authorId: data.token.claims.id
        }
    }).then(res => {
        data.comments = res.data.records;
        data.commentTotal = res.data.total;
        
        // 获取每个评论对应的文章标题
        data.comments.forEach(comment => {
            console.log('正在获取文章ID:', comment.articleId);
            request.get(`/blog/selectById/${comment.articleId}`).then(blogRes => {
                console.log('文章API返回结果:', blogRes);
                if (blogRes.code == 200) {
                    console.log('文章数据:', blogRes.data);
                    comment.articleTitle = blogRes.data.title;
                } else {
                    console.log('获取文章失败:', blogRes);
                }
            }).catch(error => {
                console.log('请求出错:', error);
            });
        });
    });
};

// 加载回复评论列表
const loadReplies = () => {
    request.get('/comment/selectPage', {
        params: {
            page: data.replyPage,
            size: data.replySize,
            toUserId: data.token.claims.id
        }
    }).then(res => {
        // 过滤掉作者ID等于当前用户ID的评论（排除自己回复自己的情况）
        data.replies = res.data.records.filter(reply => reply.authorId !== data.token.claims.id);
        data.replyTotal = data.replies.length;
        
        // 获取每个回复对应的文章标题和回复者信息
        data.replies.forEach(reply => {
            // 获取文章标题
            request.get(`/blog/selectById/${reply.articleId}`).then(blogRes => {
                if (blogRes.code == 200) {
                    reply.articleTitle = blogRes.data.title;
                }
            });
            
            // 获取回复者信息
            request.get(`/user/selectById/${reply.authorId}`).then(userRes => {
                if (userRes.code == 200) {
                    reply.author = userRes.data;
                }
            });
        });
    });
};

// 加载收藏列表
const loadFavorites = () => {
    console.log('开始加载收藏列表，当前页码:', data.favoritePage, '每页数量:', data.favoriteSize);
    request.get('/blogfavorites/list', {
        params: {
            page: data.favoritePage,
            size: data.favoriteSize
        }
    }).then(res => {
        console.log('收藏列表API响应:', res);
        if (res.code === "200") {  // 注意这里改为字符串比较
            const pageData = res.data;
            console.log('分页数据:', {
                records: pageData.records,
                total: pageData.total,
                size: pageData.size,
                current: pageData.current,
                pages: pageData.pages
            });
            
            // 处理每条博客记录
            pageData.records.forEach(blog => {
                console.log('博客详情:', {
                    id: blog.id,
                    title: blog.title,
                    descr: blog.descr,
                    cover: blog.cover,
                    readCount: blog.readCount,
                    date: blog.date,
                    tags: blog.tags,
                    categoryName: blog.categoryName
                });
            });

            data.favorites = pageData.records;
            data.favoriteTotal = pageData.total;
        } else {
            console.error('获取收藏列表失败:', res.msg || '未知错误');
            ElMessage.error('获取收藏列表失败: ' + (res.msg || '未知错误'));
        }
    }).catch(error => {
        console.error('加载收藏列表出错:', error);
        ElMessage.error('加载收藏列表出错: ' + (error.message || '未知错误'));
    });
};

// 分页处理函数
const handleBlogSizeChange = (val) => {
    data.blogSize = val;
    loadBlogs();
};

const handleBlogPageChange = (val) => {
    data.blogPage = val;
    loadBlogs();
};

const handleCommentSizeChange = (val) => {
    data.commentSize = val;
    loadComments();
};

const handleCommentPageChange = (val) => {
    data.commentPage = val;
    loadComments();
};

const handleReplySizeChange = (val) => {
    data.replySize = val;
    loadReplies();
};

const handleReplyPageChange = (val) => {
    data.replyPage = val;
    loadReplies();
};

const handleFavoriteSizeChange = (val) => {
    data.favoriteSize = val;
    loadFavorites();
};

const handleFavoritePageChange = (val) => {
    data.favoritePage = val;
    loadFavorites();
};

// 跳转到博客详情
const goToBlog = (articleId) => {
    router.push({
        path: '/blog1',
        query: {
            id: articleId,
            scrollTo: 'comment-section'
        }
    });
};

// 格式化日期
const formatDate = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    return date.toLocaleDateString();
};

const formRef = ref()

const handleUpdate = (user) =>{
    data.formVisible=true;
    data.form = JSON.parse(JSON.stringify(user));
}

const save = ()=>{
  formRef.value.validate((valid)=>{
    if(valid){
        update();
    }
  })
}

const update=()=>{
  request.put('/user/update', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

// 显示回复输入框
const showReplyInput = (reply) => {
    data.activeReplyId = reply.id;
    data.replyContents[reply.id] = '';
};

// 取消回复
const cancelReply = (reply) => {
    data.activeReplyId = null;
    data.replyContents[reply.id] = '';
};

// 提交回复
const submitReply = (reply) => {
    const content = data.replyContents[reply.id];
    if (!content?.trim()) {
        ElMessage.warning('请输入回复内容');
        return;
    }

    const replyData = {
        articleId: parseInt(reply.articleId),
        content: content,
        parent: parseInt(reply.id),
        toUserId: parseInt(reply.authorId)
    };

    request.post('/comment/create/change', replyData).then(res => {
        if (res.code == 200) {
            ElMessage.success('回复成功');
            data.activeReplyId = null;
            data.replyContents[reply.id] = '';
            loadReplies(); // 重新加载回复列表
        } else {
            ElMessage.error(res.msg || '回复失败');
        }
    }).catch(error => {
        console.error('回复出错:', error);
        ElMessage.error('回复失败');
    });
};

onMounted(() => {
    load();
    loadBlogs();
    loadComments();
    loadReplies();
    loadFavorites(); // 加载收藏列表
});
</script>

<style scoped>
body {   
    background-color: #ffffff;   
}

.container1{
    border-radius: 8px;
    max-width: 1000px;
    margin: 70px auto;
    padding: 20px;
    box-shadow: 0 2px 12px rgba(255, 255, 255, 0.1);
    background-color: rgb(252, 251, 251);
}

.me-head{
    display:flex;
    align-items:flex-start;
    padding:20px;
    height:auto;
}

.avatar1{
    height: 188px;
    width: 188px;
    padding:5px;
    border:1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.info0{
    margin-left:20px;
    display: flex;
    flex-direction: column;
    width:5000px;
}

.info1{
    margin-left:20px;
    font-size: 30px;
    font-weight:bold;
    color:#333;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-grow: 1;
}

.info2 {
    border-top: 1px solid;
    padding: 20px;
    font-size: 16px;
    color: #8a8a8a;
    flex: 1;
}

.el-button{
    padding:5px 12px;
    font-size:14px;
    border-radius:3px;
}

.info1 + .info2{
    border-top:2px solid #e0e0e0;
    margin-top: 20px;
    padding-top: 20px;
}

/* 新增样式 */
.tabs-container {
    margin-top: 20px;
    padding: 20px;
}

.blog-list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 20px;
}

.blog-item {
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    transition: transform 0.3s;
    display: flex;
    flex-direction: column;
}

.blog-item:hover {
    transform: translateY(-5px);
}

.blog-cover {
    width: 100%;
    height: 200px;
}

.blog-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.blog-info {
    padding: 15px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex: 1;
}

.blog-info h3 {
    margin: 0 0 10px;
    font-size: 18px;
    color: #333;
}

.blog-desc {
    color: #666;
    font-size: 14px;
    margin-bottom: 10px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex: 1;
}

.blog-meta {
    display: flex;
    justify-content: space-between;
    color: #999;
    font-size: 12px;
    margin-top: auto;
}

.comment-item {
    background: #fff;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.comment-content p {
    margin: 0 0 10px;
    color: #333;
}

.comment-meta {
    display: flex;
    justify-content: space-between;
    color: #999;
    font-size: 12px;
}

.el-pagination {
    margin-top: 20px;
    justify-content: center;
}

.article-link {
    color: #1e80ff;
    cursor: pointer;
    text-decoration: underline;
}

.article-link:hover {
    color: #0c6fe3;
}

.comment-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.comment-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.comment-info {
    display: flex;
    flex-direction: column;
}

.comment-author {
    font-weight: 500;
    color: #1d2129;
}

.favorite-list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 20px;
}

.favorite-item {
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    transition: transform 0.3s;
    display: flex;
    flex-direction: column;
}

.favorite-item:hover {
    transform: translateY(-5px);
}

.favorite-cover {
    width: 100%;
    height: 200px;
}

.favorite-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.favorite-info {
    padding: 15px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex: 1;
}

.favorite-info h3 {
    margin: 0 0 10px;
    font-size: 18px;
    color: #333;
}

.favorite-desc {
    color: #666;
    font-size: 14px;
    margin-bottom: 10px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex: 1;
}

.favorite-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #999;
    font-size: 12px;
    margin-top: auto;
    gap: 10px;
}
</style>