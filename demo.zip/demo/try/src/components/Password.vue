<template>
    <div class="login-container">
        <div class="login-box">
            <div style="padding:20px;background-color:rgb(252, 251, 251); border-radius:10px; box-shadow: 0 0 10px 0 rgba(0,0,0,0.1); width: 1000px;">
                <div style="margin-bottom:30px; font-size:25px; color: #0742b1; text-align:center; font-weight:bold">修改密码</div>
                <el-form class="center1" ref="formRef" :rules="data.rules" :model="data.user" style="width: 350px" >
                    <el-form-item prop="oldpassword">
                        <el-input show-password size="large" v-model="data.user.password" placeholder="请输入原密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                    <el-form-item prop="newpassword1">
                        <el-input show-password size="large" v-model="data.user.newpassword1" placeholder="请输入新密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                    <el-form-item prop="newpassword2">
                        <el-input show-password size="large" v-model="data.user.newpassword2" placeholder="请确认新密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                    <el-button @click="updatePassword" type="primary" class="login-button" size="large">提 交</el-button>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {Search, Refresh, Edit, Delete, Female} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';
import { jwtDecode } from 'jwt-decode';

const validatePass = (rule, value, callback) => {
  if (!value) {
    callback(new Error('请再次确认密码'));
  }else if(!data.user.newpassword1){
    callback(new Error('请输入密码'));
  } else if(value !== data.user.newpassword1 ){
    callback(new Error('两次输入密码不一致!'));
  }else{
    callback();
  }
}

const data= reactive({
    token:jwtDecode(localStorage.getItem('token'))||'{}', 
    user:JSON.parse(localStorage.getItem('user-info')||'{}'),
    rules:{
        newpassword1:[
            {required:true,message:"请输入密码", trigger:"blur"}
        ],
        newpassword2:[
            {validator:validatePass,trigger:"blur"}
        ]
    }
})
const formRef = ref()

const updatePassword = () => {
    formRef.value.validate(valid => {
        if(valid){
            request.post("/updatePassword",data.user).then(res=>{
                if(res.code == '200'){
                    ElMessage.success('修改成功');
                    setInterval(() => {
                        localStorage.removeItem('user_info');
                        location.href ='/login';
                    },500)
                }else{
                    ElMessage.error(res.msg);
                }
            })
        }
    })
}

</script>

<style scoped>
.login-container{
    height:100vh;
    overflow:hidden;
}
.login-box{
    display:flex;
    justify-content:center;
    align-items:top;
    height:100%;
}
.login-button{
    background-color: #76acf3;
    color: white;
    border:none;
}
.login-button:hover{
    background-color: #7c9edd;
    color: white;
}
.center1{
    margin:0 auto;
}
</style>