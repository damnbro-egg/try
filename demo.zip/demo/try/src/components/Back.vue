<template>
  <div>
    <div style="height:80px; background-color: #545c64 ; display:flex; align-items:center; ">
      <div style="width:200px; color:white; display:flex; align-items:center; gap:20px;padding:20px;">
        <img style="width:40px;" src="@/assets/images/car1.png" alt="Logo">
        <span style="font-size:24px; cursor:pointer;" @click="router.push('/homePage')">信息管理</span>
      </div>
      <div style="flex:1; color:white; display:flex; align-items:center; padding-left:20px; ">
        首页 / {{router.currentRoute.value.meta.name}}
      </div>
      <div style="width:150px; display:flex; align-items:center;">
        <!--<el-avatar :size="50" :src="data.circleUrl"/> -->
        <el-dropdown>
          <span class="el-dropdown-link">
            <div class="user-info" >
              <img style="width:40px; height:40px; border-raduis:50%;" :src="data.user.avatar">
              <span style="color:white;font-family: 'Courier New', Courier, monospace;font-weight:bold;">{{data.user?.name}}</span>
            </div>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="router.push('/homePage')">首页</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>       
      </div>
    </div>

    <div style="display: flex;" >
      <div style="width:200px;  border-right:1px solid #bdd5d1 ; min-height:calc(100vh - 60px); background-color: #545c64;">
        <el-menu 
            router 
            :default-active="$router.currentRoute.value.path"
            active-text-color="#ffd04b"
            background-color="#545c64"
            text-color="#fff"
            class="el-menu-vertical-demo"                 
        >
          <el-sub-menu index="1">
            <template #title>
              <el-icon><Service /></el-icon>
              <span>用户管理</span>
            </template>
            <el-menu-item index="/back/admin">
              <el-icon><View /></el-icon>
              <span>管理员信息</span>
            </el-menu-item>
            <el-menu-item index="/back/user">
              <el-icon><User /></el-icon>
              <span>用户信息</span>
            </el-menu-item>
          </el-sub-menu>   
          <el-menu-item index="/back/data">
            <el-icon><Van/></el-icon>
            <span>车信息管理</span>
          </el-menu-item>
          <el-menu-item index="/back/category">
            <el-icon><Rank/></el-icon>
            <span>话题分类管理</span>
          </el-menu-item>
          <el-menu-item index="/back/blog">
            <el-icon><Postcard/></el-icon>
            <span>博客管理</span>
          </el-menu-item>
          <el-menu-item index="/back/activity">
            <el-icon><Postcard/></el-icon>
            <span>活动管理</span>
          </el-menu-item>
          <el-menu-item index="/back/comment">
            <el-icon><Postcard/></el-icon>
            <span>评论管理</span>
          </el-menu-item>
          <el-menu-item @click="logout">
            <el-icon><SwitchButton/></el-icon>
              <span>退出登录</span>
          </el-menu-item>
        </el-menu>
      </div>
      <div style="flex:1; background-color:white">
        <RouterView/>
      </div>
    </div>
  </div>
</template>

<script setup>
import request from '@/utils/request';
import { reactive, toRefs } from 'vue'
import { Service } from '@element-plus/icons-vue';
import { Van } from '@element-plus/icons-vue';
import { User } from '@element-plus/icons-vue';
import { View } from '@element-plus/icons-vue';
import { Login } from '@element-plus/icons-vue';
import { SwitchButton } from '@element-plus/icons-vue';
import {ElMessage,ElMessageBox} from 'element-plus'
import router from "@/router/index.js";

const data = reactive({
  circleUrl:'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
  user:JSON.parse(localStorage.getItem('user-info')||'{}')

})
console.log(data.user.data+'-123-')

const logout = ()=>{
  ElMessageBox.confirm('确认退出吗？','退出确认',{type:'warning'}).then(()=>{
    localStorage.removeItem('user-info');
    localStorage.removeItem('token'); 
    ElMessage.success('退出成功');
    setTimeout(()=>{
      location.href = '/login';
    },500)

  }).catch(()=>{
    console.log("不行");
    ElMessage.info('已取消退出');
  })
}

</script>

<style scoped>
.el-menu .is-active{
  background-color: #45494d !important;
}
.user-info{
  width:fit-content;
  display: flex;
  align-items: center;
  justify-content: center;
  padding-right:20px;
  gap:20px;
}
.el-tooltip__trigger{
  outline:none;
}
</style>
