<template>
  <div class="car1-container">
    <div class="main-content">
      <div class="car-detail" v-if="currentCar">
        <div class="car-header">
          <div class="car-image">
            <img :src="currentCar.carPicture" :alt="currentCar.name">
          </div>
          <div class="car-basic-info">
            <h1>{{ currentCar.name }}</h1>
            <div class="car-tags">
              <el-tag>{{ currentCar.brand }}</el-tag>
              <el-tag>{{ currentCar.model }}</el-tag>
              <el-tag>{{ currentCar.carType }}</el-tag>
              <el-tag>{{ currentCar.powerType }}</el-tag>
            </div>
            <div class="car-price">
              <span class="price-label">指导价：</span>
              <span class="price-value">{{ currentCar.price }}万</span>
            </div>
          </div>
        </div>

        <div class="car-specs">
          <el-tabs v-model="activeTab">
            <el-tab-pane label="基本信息" name="basic">
              <div class="specs-grid">
                <div class="spec-item">
                  <span class="spec-label">电机类型</span>
                  <span class="spec-value">{{ currentCar.motorType }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">电机功率</span>
                  <span class="spec-value">{{ currentCar.motorPower }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">扭矩</span>
                  <span class="spec-value">{{ currentCar.torque }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">加速时间</span>
                  <span class="spec-value">{{ currentCar.acceleration }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">最高速度</span>
                  <span class="spec-value">{{ currentCar.topSpeed }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">电池类型</span>
                  <span class="spec-value">{{ currentCar.batteryType }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">电池容量</span>
                  <span class="spec-value">{{ currentCar.batteryCapacity }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">续航里程</span>
                  <span class="spec-value">{{ currentCar.range }}km</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">快充时间</span>
                  <span class="spec-value">{{ currentCar.chargeTime }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">慢充时间</span>
                  <span class="spec-value">{{ currentCar.slowChargeTime }}</span>
                </div>
              </div>
            </el-tab-pane>
            <el-tab-pane label="车身尺寸" name="dimensions">
              <div class="specs-grid">
                <div class="spec-item">
                  <span class="spec-label">车长</span>
                  <span class="spec-value">{{ currentCar.length }}mm</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">车宽</span>
                  <span class="spec-value">{{ currentCar.width }}mm</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">车高</span>
                  <span class="spec-value">{{ currentCar.height }}mm</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">轴距</span>
                  <span class="spec-value">{{ currentCar.wheelbase }}mm</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">车重</span>
                  <span class="spec-value">{{ currentCar.weight }}kg</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">座位数</span>
                  <span class="spec-value">{{ currentCar.seatNum }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">驱动方式</span>
                  <span class="spec-value">{{ currentCar.driveType }}</span>
                </div>
              </div>
            </el-tab-pane>
            <el-tab-pane label="其他信息" name="other">
              <div class="specs-grid">
                <div class="spec-item">
                  <span class="spec-label">发布日期</span>
                  <span class="spec-value">{{ currentCar.releaseDate }}</span>
                </div>
                <div class="spec-item">
                  <span class="spec-label">保修期</span>
                  <span class="spec-value">{{ currentCar.warranty }}</span>
                </div>
                <div class="spec-item full-width">
                  <span class="spec-label">描述</span>
                  <span class="spec-value">{{ currentCar.description }}</span>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>

      <!-- Move the compare table here -->
      <div class="compare-table-container" v-if="compareCars.length > 0">
        <h3>对比结果</h3>
        <div class="compare-table">
          <table>
            <tr>
              <th>项目</th>
              <th v-for="car in compareCars" :key="car.id">
                {{ car.name }}
                <button @click="removeFromCompare(car)">移除</button>
              </th>
            </tr>
            <tr v-for="(value, key) in compareFields" :key="key">
              <td>{{ value }}</td>
              <td v-for="car in compareCars" :key="car.id">{{ car[key] }}</td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <div class="sidebar">
      <div class="compare-section">
        <h3>对比车型</h3>
        <div class="compare-cars">
          <div v-for="car in otherCars" :key="car.id" class="compare-card" @click="addToCompare(car)">
            <img :src="car.carPicture" :alt="car.name">
            <div class="compare-info">
              <h4>{{ car.name }}</h4>
              <p>{{ car.price }}万</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import request from '@/utils/request';

const route = useRoute();
const currentCar = ref(null);
const otherCars = ref([]);
const compareCars = ref([]);
const activeTab = ref('basic');

const compareFields = {
  price: '价格(万)',
  motorType: '电机类型',
  motorPower: '电机功率',
  torque: '扭矩',
  acceleration: '加速时间',
  topSpeed: '最高速度',
  batteryType: '电池类型',
  batteryCapacity: '电池容量',
  range: '续航里程(km)',
  chargeTime: '快充时间',
  slowChargeTime: '慢充时间',
  length: '车长(mm)',
  width: '车宽(mm)',
  height: '车高(mm)',
  wheelbase: '轴距(mm)',
  weight: '车重(kg)',
  seatNum: '座位数',
  driveType: '驱动方式'
};

const fetchCarDetail = async (id) => {
  try {
    const res = await request.get(`/car1/selectById/${id}`);
    if (res.code == 200) {
      currentCar.value = res.data;
    }
  } catch (error) {
    console.error('获取车辆详情失败:', error);
  }
};

const fetchOtherCars = async () => {
  try {
    const res = await request.get('/car1/selectPage', {
      params: {
        page: 1,
        size: 10
      }
    });
    if (res.code == 200) {
      otherCars.value = res.data.records.filter(car => car.id != route.query.id);
    }
  } catch (error) {
    console.error('获取其他车辆失败:', error);
  }
};

const addToCompare = (car) => {
  if (compareCars.value.length < 3 && !compareCars.value.find(c => c.id === car.id)) {
    compareCars.value.push(car);
  } else if (compareCars.value.length >= 3) {
    ElMessage.warning('最多只能对比3辆车');
  }
};

const removeFromCompare = (car) => {
  compareCars.value = compareCars.value.filter(c => c.id !== car.id);
};

onMounted(() => {
  if (route.query.id) {
    fetchCarDetail(route.query.id);
    fetchOtherCars();
  }
});
</script>

<style scoped>
.car1-container {
  display: flex;
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
  gap: 20px;
}

.main-content {
  flex: 1;
}

.sidebar {
  width: 300px;
}

.car-detail {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.car-header {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
}

.car-image {
  width: 600px;
  height: 400px;
  overflow: hidden;
  border-radius: 8px;
  margin-bottom: 30px;
}

.car-image img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.car-basic-info {
  flex: 1;
}

.car-basic-info h1 {
  margin: 0 0 20px 0;
}

.car-tags {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.car-price {
  font-size: 24px;
  color: #f56c6c;
}

.specs-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  padding: 20px;
}

.spec-item {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border-bottom: 1px solid #eee;
}

.spec-item.full-width {
  grid-column: 1 / -1;
}

.spec-label {
  color: #666;
}

.spec-value {
  font-weight: bold;
}

.compare-section {
  background: white;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.compare-cars {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.compare-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border: 1px solid #eee;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s;
}

.compare-card:hover {
  background: #f5f7fa;
}

.compare-card img {
  width: 60px;
  height: 40px;
  object-fit: cover;
  border-radius: 4px;
}

.compare-info h4 {
  margin: 0;
  font-size: 14px;
}

.compare-info p {
  margin: 5px 0 0 0;
  color: #f56c6c;
  font-size: 12px;
}

.compare-table-container {
  margin-top: 30px;
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.compare-table {
  overflow-x: auto;
  margin-top: 20px;
  width: 100%;
}

.compare-table table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

.compare-table th,
.compare-table td {
  padding: 15px;
  border: 1px solid #eee;
  text-align: center;
  min-width: 120px;
}

.compare-table th {
  background: #f5f7fa;
  font-weight: bold;
  color: #333;
  position: sticky;
  left: 0;
  z-index: 1;
}

.compare-table tr:hover {
  background-color: #f5f7fa;
}

.compare-table td:first-child {
  position: sticky;
  left: 0;
  background: #f5f7fa;
  z-index: 1;
}
</style>