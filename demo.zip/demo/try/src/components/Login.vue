<template>
    <div class="login-container">
        <div class="login-box">
            <div style="padding:20px; margin-left:200px ;background-color:#fff; border-radius:10px; box-shadow: 0 0 10px 0 rgba(0,0,0,0.1);">
                <div style="margin-bottom:30px; font-size:25px; color: #0742b1; text-align:center; font-weight:bold">欢迎登录</div>
                <el-form ref="formRef" :rules="data.rules" :model="data.form" style="width: 350px" >
                    <el-form-item prop="username">
                        <el-input size="large" v-model="data.form.username" placeholder="请输入账号" prefix-icon="User"></el-input>
                    </el-form-item>
                    <el-form-item prop="password">
                        <el-input show-password size="large" v-model="data.form.password" placeholder="请输入密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                    <el-form-item prop="role">
                        <el-radio-group v-model="data.form.role">
                            <el-radio value="USER" label="用户"></el-radio>
                            <el-radio value="ADMIN" label="管理员"></el-radio> 
                        </el-radio-group> 
                    </el-form-item>
                </el-form>
                <div>
                    <el-button @click="login" type="primary" class="login-button" size="large">登 录</el-button>
                </div>
                <div style=" text-align:right; margin-top:20px;">还没有账号？请 <a style="color:#0742b1; text-decoration:none;" href="/register">注册</a></div>
            </div>
        </div>
    </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {User} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
import { jwtDecode } from 'jwt-decode';

const data= reactive({
    form:{role:'USER'},
    rules:{
        username:[
            {required:true,message:"请输入账号", trigger:"blur"}
        ],
        password:[
            {required:true,message:"请输入密码", trigger:"blur"}
        ]
    }
})
const formRef = ref()

const login = () => {
    formRef.value.validate((valid)=>{
        if(valid){
            request.post("/login",data.form).then(res=>{
                if(res.code==200){
                    const token = res.data.token;
                    localStorage.setItem('token',token);

                    const info = jwtDecode(token).claims;
                    console.log(info);

                    const userInfo = res.data.admin || res.data.user;
                    localStorage.setItem('user-info',JSON.stringify(userInfo))
                    console.log(localStorage.getItem('user-info')+'-111-')
                    ElMessage.success("登录成功")
                    setTimeout(()=>{
                        location.href = '/homePage'
                    },500)
                }else{
                    ElMessage.error(res.msg)
                }
            }).catch(err=>{
                console.log('登录失败',err);
                ElMessage.error('登录异常，请检查控制台');
            })
        }
    })
}
</script>

<style scoped>
.login-container{
    height:100vh;
    overflow:hidden;
    background-image: url('@/assets/images/login-bg3.jpg');
    background-size: cover;
    background-position: center;
}
.login-box{
    position:absolute;
    width:50%;
    right:0;
    height:100%;
    display:flex;
    align-items:center;
    position:absolute;
    opacity:0.9;
}
.login-button{
    background-color: #0742b1;
    width:100%;
    color: white;
}
.login-button:hover{
    background-color: #7c9edd;
    color: white;
}
</style>