<template>
  <div class="home-container">
    <div class="banner-section">
      <el-carousel height="400px">
        <el-carousel-item v-for="item in bannerList" :key="item.id" @click="goToBlog(item.id)">
          <img :src="item.imageUrl" :alt="item.title">
          <div class="banner-text">
            <h2>{{ item.title }}</h2>
            <p>{{ item.description }}</p>
          </div>
        </el-carousel-item>
      </el-carousel>
    </div>

    <div class="hot-section">
      <h2 class="section-title">热门推荐</h2>
      <div class="hot-grid">
        <div v-for="(item, index) in hotTopics" :key="item.id" class="hot-item" @click="goToBlog(item.id)">
          <div class="hot-rank" :class="{'top-three': index < 3}">{{ index + 1 }}</div>
          <img :src="item.cover" :alt="item.title">
          <div class="hot-item-info">
            <h3>{{ item.title }}</h3>
            <h4 class="preview-text" :title="item.descr">{{ item.descr }}</h4>
            <div class="item-stats">
              <span><i class="fa fa-eye"></i> {{ item.readCount }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
<!--
    <div class="news-section">
      <h2 class="section-title">最新资讯</h2>
      <div class="news-list">
        <div v-for="news in newsList" :key="news.id" class="news-item">
          <img :src="news.imageUrl" :alt="news.title">
          <div class="news-content">
            <h3>{{ news.title }}</h3>
            <p>{{ news.summary }}</p>
            <div class="news-meta">
              <span>{{ news.date }}</span>
              <span>{{ news.author }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>-->
  </div>
  
</template>

<script>
import request from '@/utils/request';

export default {
  data() {
    return {
      bannerList: [],
      hotTopics: [],
      newsList: [
        {
          id: 1,
          imageUrl: 'https://s3.xchuxing.com/xchuxing/article/2025/02/25/a356e202502252040376636.png?imageView2/2/w/500/q/100',
          title: '小鹏G9正式上市',
          summary: '售价309,900元起，搭载800V超充技术',
          date: '2024-03-20',
          author: '新能源观察'
        },
        {
          id: 2,
          imageUrl: 'https://images.unsplash.com/photo-1470770903676-69b98201ea1c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
          title: 'Model Y销量创新高',
          summary: '2月销量突破3万台，创历史新高',
          date: '2024-03-19',
          author: '汽车周刊'
        },
        {
          id: 3,
          imageUrl: 'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
          title: '蔚来第三代换电站发布',
          summary: '单站容量提升50%，充电速度更快',
          date: '2024-03-18',
          author: '电动邦'
        },
        {
          id: 4,
          imageUrl: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80',
          title: '比亚迪海豹销量破万',
          summary: '2月销量达10,528台，同比增长128%',
          date: '2024-03-17',
          author: '新能源观察'
        }
      ]
    }
  },
  mounted() {
    this.loadHotBlogs();
    this.loadBannerData();
  },
  methods: {
    loadBannerData() {
      request.get('/blog/selectPage', {
        params: {
          page: 1,
          size: 100  // 获取足够多的数据以便随机选择
        }
      }).then(res => {
        if (res.data && res.data.records) {
          // 随机选择3个博客作为banner
          const allBlogs = res.data.records;
          const randomBlogs = this.getRandomItems(allBlogs, 3);
          
          this.bannerList = randomBlogs.map(blog => ({
            id: blog.id,
            imageUrl: blog.cover,
            title: blog.title,
            description: blog.descr
          }));
        }
      });
    },
    getRandomItems(array, count) {
      const shuffled = [...array].sort(() => 0.5 - Math.random());
      return shuffled.slice(0, count);
    },
    loadHotBlogs() {
      request.get('/blog/selectHot', {
        params: {
          num: 3  // 只获取前3个热门博客
        }
      }).then(res => {
        if (res.data) {
          this.hotTopics = res.data || [];
        }
      });
    },
    goToBlog(id) {
            this.$router.push({
                path: '/blog1',
                query: { id: id }
            });
        },
    submitComment() {
      if (!this.commentContent.trim()) {
        this.$message.warning('请输入评论内容');
        return;
      }

        }
  }
}
</script>

<style scoped>
.home-container {
  padding-top:10px; 
  max-width: 1200px;
  margin: 0 auto;
}

.banner-section {
  margin: 0px 0;
}


.el-carousel__item img {
  width:100%;
  height:auto;
  background: #f5f5f5;
}

.banner-text {
  position: absolute;
  bottom:0;
  left: 0px;
  color: white;
  text-shadow: 0 2px 4px rgba(0,0,0,0.5);
  background: rgba(0, 0, 0, 0.5);
  padding: 15px 20px;
  border-radius: 8px;
}

.banner-text h2 {
  font-size: 18px;
  margin-bottom: 5px;
}

.banner-text p {
  font-size: 14px;
  margin: 0;
}

.section-title {
  font-size: 24px;
  margin: 40px 0 20px;
  font-weight: bold;
}

.hot-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.hot-item {
  position: relative;
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.5);
  transition: all 0.3s;
  cursor: pointer;
}

.hot-rank {
  position: absolute;
  top: 10px;
  left: 10px;
  width: 24px;
  height: 24px;
  line-height: 24px;
  text-align: center;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  font-weight: bold;
  color: #666;
}

.top-three {
  background-color: #ff4d4f;
  color: white;
}

.hot-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.hot-item img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.hot-item-info {
  padding: 15px;
}

.hot-item-info h3 {
  margin-bottom: 8px;
  font-size: 16px;
  line-height: 1.4;
}

.hot-item-info h4 {
  margin-bottom: 8px;
  font-size: 16px;
  line-height: 1.4;
}

.hot-item-info p {
  color: #666;
  font-size: 14px;
  line-height: 1.5;
  margin-bottom: 10px;
  white-space: nowrap;           /* 文本不换行 */
  overflow: hidden;              /* 超出部分隐藏 */
  text-overflow: ellipsis;       /* 显示省略号 */
  cursor: pointer;               /* 鼠标悬浮时显示指针 */
}

.item-stats {
  display: flex;
  gap: 15px;
  color: #666;
  margin-top: 10px;
}

.news-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  margin-bottom:30px;
}

.news-item {
  display: flex;
  gap: 15px;
  padding: 15px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.news-item img {
  width: 200px;
  height: 134px;
  object-fit: cover;
  border-radius: 4px;
}

.news-meta {
  margin-top: 10px;
  color: #666;
  font-size: 14px;
}

.preview-text {
  color: #666;
  font-size: 13px;
  font-weight: 300;
  line-height: 1.4;
  margin-bottom: 10px;
  white-space: nowrap;           /* 文本不换行 */
  overflow: hidden;              /* 超出部分隐藏 */
  text-overflow: ellipsis;       /* 显示省略号 */
  cursor: pointer;               /* 鼠标悬浮时显示指针 */
}
</style>