<template>
    <div class="login-container">
        <div class="login-box">
            <div style="padding:20px; margin-left:200px ;background-color:#fff; border-radius:10px; box-shadow: 0 0 10px 0 rgba(0,0,0,0.1);">
                <div style="margin-bottom:30px; font-size:25px; color: #0742b1; text-align:center; font-weight:bold">欢迎注册</div>
                <el-form ref="formRef" :rules="data.rules" :model="data.form" style="width: 350px" >
                    <el-form-item prop="username">
                        <el-input size="large" v-model="data.form.username" placeholder="请输入账号" prefix-icon="User"></el-input>
                    </el-form-item>
                    <el-form-item prop="password">
                        <el-input show-password size="large" v-model="data.form.password" placeholder="请输入密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                    <el-form-item prop="confirmPassword">
                        <el-input show-password size="large" v-model="data.form.confirmPassword" placeholder="请确认密码" prefix-icon="Lock"></el-input>
                    </el-form-item>
                </el-form>
                <div>
                    <el-button @click="register" type="primary" class="login-button" size="large">注 册</el-button>
                </div>
                <div style=" text-align:right; margin-top:20px;">已有账号？请 <a style="color:#0742b1; text-decoration:none;" href="/login">登陆</a></div>
            </div>
        </div>
    </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {User} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
import { useRoute } from 'vue-router';

const router = useRouter();
const route = useRoute();

const validatePass = (rule, value, callback) => {
  if (!value) {
    callback(new Error('请再次确认密码'));
  }else if(!data.form.password){
    callback(new Error('请输入密码'))
  } else if(value !== data.form.password ){
        callback(new Error('两次输入密码不一致!'))
  }else{
    callback()
  }
}

const data= reactive({
    form:{},
    rules:{
        username:[
            {required:true,message:"请输入账号", trigger:"blur"}
        ],
        password:[
            {required:true,message:"请输入密码", trigger:"blur"}
        ],
        confirmPassword:[
            {validator:validatePass,trigger:"blur"}
        ]

    }
})
const formRef = ref()

const register = () => {
    formRef.value.validate((valid)=>{
        if(valid){
            request.post("/register",data.form).then(res=>{
                if(res.code==200){
                    localStorage.setItem('xm-pro-user',JSON.stringify(res.data))
                    console.log(localStorage.getItem('xm-pro-user')+'-111-')
                    ElMessage.success("注册成功")
                    setTimeout(()=>{
                        location.href = '/login'
                    },1000)       
                }else{
                    ElMessage.error(res.msg)
                }
            })
        }
    })
}
</script>

<style scoped>
.login-container{
    height:100vh;
    overflow:hidden;
    background-image: url('@/assets/images/login-bg2.jpg');
    background-size: cover;
    background-position: center;
}
.login-box{
    position:absolute;
    width:50%;
    right:0;
    height:100%;
    display:flex;
    align-items:center;
    position:absolute;
}
.login-button{
    background-color: #0742b1;
    width:100%;
    color: white;
}
.login-button:hover{
    background-color: #7c9edd;
    color: white;
}
</style>