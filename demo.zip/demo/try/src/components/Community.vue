<template>
    <div class="main-content">
        <div class="content-wrapper">
            <!-- 左侧分类列表 -->
            <div class="category-card fixed-card">
                <div class="category-title">分类</div>
                <div class="category-list">
                    <div class="category-item" 
                         :class="{'category-item-active':item.name === current}" 
                         v-for="item in categoryList" 
                         :key="item.id" 
                         @click="selectCategory(item.name)">
                        <span>{{ item.name }}</span>
                    </div>
                </div>
            </div>

            <!-- 中间博客列表 -->
            <div class="blog-card scrollable-card">
                <div class="blog-list">
                    <div v-for="blog in blogData" :key="blog.id" class="blog-item" @click="goToBlog(blog.id)">
                        <div class="blog-content">
                            <div class="blog-main">
                                <h2 class="blog-title">{{ blog.title }}</h2>
                                <div class="blog-descr">{{ blog.descr }}</div>
                                <div class="blog-meta">
                                    <div class="meta-left">
                                        <span class="meta-item">
                                            <i class="fa fa-user"></i>
                                            {{ blog.userName }}
                                        </span>
                                        <span class="meta-item">
                                            <i class="fa fa-eye"></i>
                                            {{ blog.readCount }}
                                        </span>
                                        <span class="meta-item">
                                            <i class="fa fa-calendar"></i>
                                            {{ blog.date }}
                                        </span>
                                    </div>
                                    <div class="meta-right">
                                        <el-tag v-for="tag in JSON.parse(blog.tags || '[]')" 
                                               :key="tag" 
                                               size="small"
                                               effect="plain">{{ tag }}</el-tag>
                                    </div>
                                </div>
                            </div>
                            <div class="blog-cover">
                                <img :src="blog.cover || '/default-cover.jpg'" alt="cover">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="pagination-wrapper">
                    <el-pagination
                        v-model:current-page="currentPage"
                        v-model:page-size="pageSize"
                        :page-sizes="[10, 20, 30, 40]"
                        :background="true"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total"
                        @size-change="loadBlogs"
                        @current-change="loadBlogs"
                    />
                </div>
            </div>

            <!-- 右侧热门博客 -->
            <div class="hot-card fixed-card">
                <div class="hot-title">
                    <i class="fa fa-fire"></i>
                    热门文章
                </div>
                <div class="hot-list">
                    <div v-for="(blog, index) in hotBlogs" 
                         :key="blog.id" 
                         class="hot-blog-item"
                         @click="goToBlog(blog.id)">
                        <div class="hot-blog-rank" :class="{'top-three': index < 3}">
                            {{ index + 1 }}
                        </div>
                        <div class="hot-blog-content">
                            <div class="hot-blog-title">{{ blog.title }}</div>
                            <div class="hot-blog-count">
                                <i class="fa fa-eye"></i> {{ blog.readCount }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import request from '@/utils/request';
import { onMounted, watch } from 'vue';
import { useRoute } from 'vue-router';

export default {
    data() {
        return {
            current: '全部博客',
            categoryList: [],
            blogData: [],
            hotBlogs: [],
            currentPage: 1,
            pageSize: 10,
            total: 0,
            title: '',
            categoryName: '',
            userName: '',
        }
    },
    setup() {
        const route = useRoute();
        
        // 监听路由参数变化
        watch(() => route.query.title, (newTitle) => {
            if (newTitle) {
                this.title = newTitle;
                this.loadBlogs();
            }
        });

        return {
            route
        };
    },
    mounted() {
        this.loadCategories();
        this.loadBlogs();
        this.loadHotBlogs();
        
        // 检查URL中是否有搜索参数
        if (this.route.query.title) {
            this.title = this.route.query.title;
            this.loadBlogs();
        }
    },
    methods: {
        selectCategory(categoryName) {
            this.current = categoryName;
            this.categoryName = categoryName === '全部博客' ? '' : categoryName;
            this.loadBlogs();
        },
        loadCategories() {
            request.get('/category/selectAll').then(res => {
                this.categoryList = res.data || [];
                this.categoryList.unshift({id: 0, name: '全部博客'});
            })
        },
        loadBlogs() {
            request.get('/blog/selectPage', {
                params: {
                    page: this.currentPage,
                    size: this.pageSize,
                    title: this.title,
                    categoryName: this.categoryName,
                    userName: this.userName
                }
            }).then(res => {
                if (res.data && Array.isArray(res.data.records)) {
                    this.blogData = res.data.records;
                } else {
                    this.blogData = [];
                }
                this.total = res.data.total;
            })
        },
        loadHotBlogs() {
            request.get('/blog/selectHot', {
                params: {
                    num: 5
                }
            }).then(res => {
                this.hotBlogs = res.data || [];
            })
        },
        goToBlog(id) {
            this.$router.push({
                path: '/blog1',
                query: { id: id }
            });
        }
    }
}
</script>

<style>
.main-content {
    width: 100%;
    max-width: 1200px;
    margin: 20px auto;
    padding: 0 20px;
    min-height: calc(100vh - 40px);
    position: relative;
}

.content-wrapper {
    display: flex;
    gap: 20px;
    position: relative;
    min-height: calc(100vh - 40px);  /* 确保有足够高度 */
}

.card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

/* 固定卡片样式 */
.fixed-card {
    position: sticky;
    top: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

/* 左侧分类样式 */
.category-card {
    width: 160px;
    padding: 20px;
    background-color: #fff;
    position: sticky;  /* 改为sticky定位 */
    top: 70px;         /* 距离顶部20px */
    height: fit-content;  /* 适应内容高度 */
    z-index: 2;        /* 确保层级正确 */
}

.category-title {
    font-size: 16px;
    font-weight: 600;
    color: #1d2129;
    margin-bottom: 16px;
}

.category-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.category-item {
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s;
    color: #4e5969;
    font-size: 14px;
}

.category-item:hover {
    background-color: #f2f3f5;
    color: #1d2129;
}

.category-item-active {
    background-color: #e8f3ff;
    color: #1e80ff;
}

/* 中间博客列表样式 */
.blog-card {
    flex: 1;
    padding: 20px;
    background-color: #fff;
}

.blog-list {
    display: flex;
    flex-direction: column;
    
}

.blog-item {
    padding: 16px;
    border-bottom: 1px solid #e5e6eb;
    transition: all 0.3s;
}

.blog-item:last-child {
    border-bottom: none;
}

.blog-item:hover {
    background-color: #f7f8fa;
}

.blog-content {
    display: flex;
    gap: 20px;
}

.blog-main {
    flex: 1;
}

.blog-title {
    font-size: 18px;
    font-weight: 600;
    color: #1d2129;
    margin-bottom: 12px;
    line-height: 1.4;
}

.blog-descr {
    font-size: 14px;
    color: #4e5969;
    margin-bottom: 16px;
    line-height: 1.6;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.blog-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
}

.meta-left {
    display: flex;
    gap: 16px;
}

.meta-item {
    color: #86909c;
    display: flex;
    align-items: center;
    gap: 4px;
}

.meta-right {
    display: flex;
    gap: 8px;
}

.blog-cover {
    width: 120px;
    height: 80px;
    border-radius: 6px;
    overflow: hidden;
    flex-shrink: 0;
}

.blog-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.pagination-wrapper {
    margin-top: 24px;
    display: flex;
    justify-content: center;
}

/* 右侧热门博客样式 */
.hot-card {
    width: 240px;
    padding: 20px;
    background-color: #fff;
    position: sticky;  /* 改为sticky定位 */
    top: 70px;         /* 距离顶部20px */
    height: fit-content;  /* 适应内容高度 */
    z-index: 2;        /* 确保层级正确 */
}

.hot-title {
    font-size: 16px;
    font-weight: 600;
    color: #1d2129;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.hot-title i {
    color: #ff4d4f;
}

.hot-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.hot-blog-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s;
}

.hot-blog-item:hover {
    background-color: #f7f8fa;
}

.hot-blog-rank {
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    background-color: #f2f3f5;
    border-radius: 50%;
    font-size: 13px;
    color: #86909c;
}

.top-three {
    background-color: #ff4d4f;
    color: white;
}

.hot-blog-content {
    flex: 1;
}

.hot-blog-title {
    font-size: 14px;
    color: #1d2129;
    margin-bottom: 4px;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.hot-blog-count {
    font-size: 12px;
    color: #86909c;
}

/* 响应式布局 */
@media screen and (max-width: 1200px) {
    .content-wrapper {
        flex-direction: column;
    }
    
    .category-card,
    .hot-card {
        width: 100%;
        position: static;  /* 在小屏幕下取消固定定位 */
        top: 0;           /* 重置top值 */
    }
    
    .blog-content {
        flex-direction: column;
    }
    
    .blog-cover {
        width: 100%;
        height: 200px;
    }
}
</style>