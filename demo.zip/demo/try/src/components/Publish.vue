<template>
  <div class="publish-container">
    <div class="publish-header">
      <h1>发布博客</h1>
      <p>分享你的想法和经验</p>
    </div>
    <el-card class="publish-card">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px" class="publish-form">
        <el-form-item label="标题" prop="title">
          <el-input 
            v-model="form.title" 
            placeholder="请输入标题"
            class="title-input"
          >
            <template #prefix>
              <el-icon><Document /></el-icon>
            </template>
          </el-input>
        </el-form-item>
        
        <el-form-item label="描述" prop="descr">
          <el-input 
            v-model="form.descr" 
            type="textarea" 
            :rows="3"
            placeholder="请输入描述"
            class="descr-input"
          >
            <template #prefix>
              <el-icon><ChatLineRound /></el-icon>
            </template>
          </el-input>
        </el-form-item>
        
        <el-form-item label="封面" prop="cover">
          <el-upload
            class="cover-uploader"
            :action="'http://localhost:8088/files/upload'"
            :headers="{ Authorization: 'Bearer ' + token }"
            :on-success="handleFileSuccess"
            :show-file-list="false"
          >
            <img v-if="form.cover" :src="form.cover" class="cover-image" />
            <div v-else class="upload-placeholder">
              <el-icon><Picture /></el-icon>
              <span>点击上传封面</span>
            </div>
          </el-upload>
        </el-form-item>
        
        <el-form-item label="标签" prop="tags">
          <el-select 
            v-model="tagsArr" 
            multiple 
            filterable 
            allow-create 
            default-first-option 
            class="tags-select"
            placeholder="请选择标签"
          >
            <el-option value="电车生活"></el-option>
            <el-option value="电车评测"></el-option>
            <el-option value="体验分享"></el-option>
            <el-option value="科普"></el-option>
            <el-option value="新闻快讯"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="分类" prop="categoryId">
          <el-select 
            v-model="form.categoryId" 
            class="category-select"
            placeholder="请选择分类"
          >
            <el-option v-for="item in categoryList" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="内容" prop="content">
          <div id="editor" class="editor-container"></div>
        </el-form-item>
        
        <el-form-item class="form-actions">
          <el-button type="primary" @click="submitForm" class="submit-btn">
            <el-icon><Upload /></el-icon>
            发布
          </el-button>
          <el-button @click="resetForm" class="reset-btn">
            <el-icon><Refresh /></el-icon>
            重置
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue';
import { 
  Plus, 
  Document, 
  ChatLineRound, 
  Picture, 
  Upload, 
  Refresh 
} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage, ElMessageBox } from 'element-plus';
import E from "wangeditor";
import hljs from 'highlight.js';

const formRef = ref();
const editor = ref(null);
const token = localStorage.getItem('token') || '{}';

const form = reactive({
  title: '',
  descr: '',
  cover: '',
  content: '',
  categoryId: '',
  tags: ''
});

const tagsArr = ref([]);
const categoryList = ref([]);

const rules = {
  title: [
    { required: true, message: '请输入标题', trigger: 'blur' }
  ],
  descr: [
    { required: true, message: '请输入描述', trigger: 'blur' }
  ],
  categoryId: [
    { required: true, message: '请选择分类', trigger: 'change' }
  ]
};

const handleFileSuccess = (res) => {
  form.cover = res.data;
};

const setRichText = () => {
  setTimeout(() => {
    editor.value = new E(`#editor`);
    editor.value.highlight = hljs;
    editor.value.config.uploadImgServer = 'http://localhost:8088/files/editor/upload';
    editor.value.config.uploadFileName = 'file';
    editor.value.config.uploadImgHeaders = {
      Authorization: 'Bearer ' + token
    };
    editor.value.config.uploadImgParams = {
      type: 'img',
    };
    editor.value.create();
  }, 0);
};

const submitForm = () => {
  formRef.value.validate((valid) => {
    if (valid) {
      form.content = editor.value.txt.html();
      if (!form.content || form.content.trim() == '') {
        ElMessage.warning('请输入博客内容');
        return;
      }
      form.tags = JSON.stringify(tagsArr.value);
      
      ElMessageBox.confirm(
        '确定要发布这篇博客吗？',
        '发布确认',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).then(() => {
        request.post('/blog/add', form).then(res => {
          if (res.code == 200) {
            ElMessage.success('发布成功');
            resetForm();
          } else {
            ElMessage.error(res.msg || '发布失败');
          }
        });
      }).catch(() => {
        ElMessage.info('已取消发布');
      });
    }
  });
};

const resetForm = () => {
  formRef.value.resetFields();
  tagsArr.value = [];
  editor.value.txt.clear();
};

onMounted(() => {
  setRichText();
  request.get('/category/selectAll').then(res => {
    categoryList.value = res.data || [];
  });
});
</script>

<style scoped>
.publish-container {
  max-width: 1200px;
  margin: 20px auto;
  padding: 0 20px;
}

.publish-header {
  text-align: center;
  margin-bottom: 30px;
  padding: 40px 0;
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
              url('https://s3.xchuxing.com/xchuxing/carousel/2025/02/25/8e2f0202502251024526264.jpg');
  background-size: cover;
  background-position: center;
  border-radius: 10px;
  color: white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.publish-header h1 {
  font-size: 28px;
  margin-bottom: 10px;
}

.publish-header p {
  font-size: 16px;
  opacity: 0.9;
}

.publish-card {
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border: none;
}

.publish-form {
  padding: 20px;
  position: relative;
  z-index: 1;
}

.title-input, .descr-input {
  width: 100%;
}

.title-input :deep(.el-input__wrapper) {
  padding: 8px 15px;
  border-radius: 8px;
}

.descr-input :deep(.el-textarea__inner) {
  padding: 8px 15px;
  border-radius: 8px;
  min-height: 100px !important;
}

.cover-uploader {
  width: 100%;
  max-width: 300px;
  height: 200px;
  border: 2px dashed var(--el-border-color);
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: all 0.3s;
}

.cover-uploader:hover {
  border-color: var(--el-color-primary);
  transform: translateY(-2px);
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--el-text-color-secondary);
}

.upload-placeholder .el-icon {
  font-size: 40px;
  margin-bottom: 10px;
}

.cover-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.tags-select, .category-select {
  width: 100%;
}

:deep(.el-select-dropdown) {
  z-index: 9999 !important;
}

:deep(.el-select) {
  z-index: 9999;
}

:deep(.el-popper) {
  z-index: 9999 !important;
}

:deep(.el-select__popper) {
  z-index: 9999 !important;
}

:deep(.el-select-dropdown__wrap) {
  z-index: 9999 !important;
}

.tags-select :deep(.el-select__tags) {
  flex-wrap: nowrap;
  overflow-x: auto;
}

.editor-container {
  border: 1px solid var(--el-border-color);
  border-radius: 8px;
  overflow: hidden;
}

.form-actions {
  margin-top: 30px;
  text-align: center;
}

.submit-btn, .reset-btn {
  padding: 12px 24px;
  font-size: 16px;
  border-radius: 8px;
}

.submit-btn {
  background: linear-gradient(135deg, #409EFF 0%, #36D1DC 100%);
  border: none;
  color: white;
}

.submit-btn:hover {
  opacity: 0.9;
  transform: translateY(-2px);
}

.reset-btn {
  margin-left: 20px;
}

.reset-btn:hover {
  transform: translateY(-2px);
}

:deep(.el-form-item__label) {
  font-weight: 500;
  color: var(--el-text-color-primary);
}

:deep(.el-input__wrapper), 
:deep(.el-textarea__inner) {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

:deep(.el-input__wrapper:hover), 
:deep(.el-textarea__inner:hover) {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

:deep(.el-input__wrapper.is-focus), 
:deep(.el-textarea__inner:focus) {
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.2);
}
</style>
