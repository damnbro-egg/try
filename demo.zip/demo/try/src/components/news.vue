<template>
<h1>新闻资讯</h1>
</template>

<script>

</script>

<style>

</style>