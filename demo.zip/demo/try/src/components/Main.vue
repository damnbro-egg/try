<template>
    <div id="main">
      <div class="header">
        <div class="header-content">
          <div class="logo">
            <img src="@/assets/images/icon1.png" alt="Logo">
            <span>能源新时代</span>
          </div>
          <nav class="main-nav">
            <div class="nav-links">
              <router-link to="/homePage" class="nav-item">
                <i class="fa fa-home"></i>
                首页
              </router-link>
              <router-link to="/car" class="nav-item">
                <i class="fa fa-car"></i>
                产品库
              </router-link>
              <router-link to="/community" class="nav-item">
                <i class="fa fa-users"></i>
                社区
              </router-link>
              <router-link to="/news" class="nav-item">
                <i class="fa fa-newspaper-o"></i>
                资讯
              </router-link>
            </div>
          </nav>
          <div class="header-right">
            <div class="search-box">
              <input type="text" v-model="searchText" placeholder="搜索博客" @keyup.enter="handleSearch">
              <button class="search-btn" @click="handleSearch">
                <i class="fa fa-search"></i>
              </button>
            </div>
            <div class="user-actions">
              <router-link to="/publish" class="publish-btn">
                <i class="fa fa-edit"></i>
                发布
              </router-link>
              <div class="user-avatar">
                <div class="avatar1" @mouseenter="handleMouseEnter" @mouseleave="handleMouseLeave">
                  <img :src="data.user.avatar" alt="用户头像">
                </div>
                <div v-if="showMenu" class="popup-menu" @mouseenter="handleMouseEnter" @mouseleave="handleMouseLeave">
                  <span>{{data.user.name}}</span>
                  <ul >
                    <li @click="router.push('/me')">
                      <el-icon><User /></el-icon>个人主页
                    </li>                    
                    <li @click="router.push('/password');"><el-icon><Tools/></el-icon>修改密码</li>
                    <li @click="navBack"><el-icon><InfoFilled /></el-icon>信息管理</li>
                    <li @click="logout"><el-icon><SwitchButton/></el-icon>退出登录</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="main-content">
        <router-view></router-view>
      </div>
    </div>
  </template>
  
<script setup>
import { jwtDecode } from 'jwt-decode';
import {reactive,ref} from 'vue';
import request from '@/utils/request';
import { Service } from '@element-plus/icons-vue';
import { Van } from '@element-plus/icons-vue';
import { User } from '@element-plus/icons-vue';
import { View } from '@element-plus/icons-vue';
import { Login } from '@element-plus/icons-vue';
import { SwitchButton } from '@element-plus/icons-vue';
import {ElMessage,ElMessageBox} from 'element-plus';
import { useRouter } from 'vue-router';

const showMenu = ref(false);
const data = reactive({
    user:JSON.parse(localStorage.getItem('user-info')) || {},
         
});


let timeoutId = null;
const handleMouseEnter=()=>{
  clearTimeout(timeoutId);
  showMenu.value=true;
};

const handleMouseLeave=()=>{
  timeoutId = setTimeout(()=>{
      showMenu.value = false;
  },500);
};

const logout = ()=>{
  ElMessageBox.confirm('确认退出吗？','退出确认',{type:'warning'}).then(()=>{
    localStorage.removeItem('user-info');
    localStorage.removeItem('token'); 
    ElMessage.success('退出成功');
    setTimeout(()=>{
      location.href = '/login';
    },500)

  }).catch(()=>{
    console.log("不行");
    ElMessage.info('已取消退出');
  })
}

const router = useRouter();

const navBack = () =>{
  router.push('/back');
};

const searchText = ref('');
const handleSearch = () => {
    if (searchText.value.trim()) {
        router.push({
            path: '/community',
            query: { title: searchText.value.trim() }
        });
        searchText.value = ''; // 清空搜索框
    }
};
</script>
  
  <style>
  * {
    margin: 0;
    padding: 0;
    /*box-sizing: border-box;
    box-shadow:10px 5px 5px rgb(0, 0, 0)*/
  }
  
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background-color: #f1f1f1;
    color: #333;
    line-height: 1.6;
  }
  
  .header {
    background: #ffffff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 10;
  }
  
  .header-content {
    max-width: 1200px;
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 200px;
  }
  
  .logo {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 200px;
  }
  
  .logo img {
    height: 64px;
  }
  
  .logo span {
    font-size: 20px;
    font-weight: bold;
    color: #333;
  }
  
  .main-nav {
    flex: 1;
    margin: 0 20px;
  }
  
  .nav-links {
    display: flex;
    gap: 20px;
    justify-content: space-around;
  }
  
  .nav-item {
    font-family: '微软雅黑';
    text-decoration: none;
    color: #666;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 8px 10px;
    border-radius: 4px;
    transition: all 0.3s;
    white-space: nowrap;
  }
  
  .nav-item:hover, .nav-item.router-link-active {
    color: #409EFF;
    background: rgba(64,158,255,0.1);
  }
  
  .nav-item i {
    font-size: 16px;
  }
  
  .header-right {
    display: flex;
    align-items: center;
    gap: 16px;
    min-width: 320px;
  }
  
  .search-box {
    position: relative;
    display: flex;
    align-items: center;
  }
  
  .search-box input {
    width: 200px;
    height: 36px;
    padding: 0 36px 0 12px;
    border: 1px solid #ddd;
    border-radius: 18px;
    font-size: 14px;
    transition: all 0.3s;
    background-color: #f5f5f5;
  }
  
  .search-box input:focus {
    width: 240px;
  }
  
  .search-btn {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);
    width: 32px;
    height: 32px;
    border: none;
    background: none;
    color: #666;
    cursor: pointer;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s;
  }
  
  .search-btn:hover {
    color: #409EFF;
    background-color: rgba(64,158,255,0.1);
  }
  
  .search-btn i {
    font-size: 16px;
  }
  
  .user-actions {
    display: flex;
    align-items: center;
    gap: 16px;
  }
  
  .publish-btn {
    height: 36px;
    padding: 0 16px;
    border: none;
    background: #409EFF;
    color: white;
    border-radius: 18px;
    font-size: 14px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s;
  }
  
  .publish-btn:hover {
    background: #66b1ff;
  }
  
  .user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
    overflow:hidden;
  }

  .user-avatar img {
    width: 100%;
    height: 100%;
    object-fit:fill;
  }

  .popup-menu{
    position: absolute;
    transform:translateX(-37%);
    color: black;
    background: rgba(255, 255, 255, 1);
    padding: 15px 20px;
    border-radius: 5%;
    transition:all 0.3s;
    z-index:30;
  }
  
  .popup-menu::before {
    content: '';
    position: absolute;
    top: -10px; 
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 10px solid transparent; 
    border-right: 10px solid transparent; 
    border-bottom: 10px solid rgba(255, 255, 255, 1); 
  }

  .popup-menu:hover{
    box-shadow:10px -2px 5px #616161;
  }
  
  .popup-menu ul{
    list-style:none;
    margin:0;
    padding:0;
    transition: all 0.5s;
  }

  .popup-menu span {
    padding: 8px 16px; 
    display: flex; 
    align-items: center; 
    justify-content: center; 
    border-bottom: 1px solid #ccc; 
}

  .popup-menu li{
    padding: 8px 16px;
    transition: all 0.5s;
    display:flex;
    align-items: center;
    justify-content: space-between;
    gap:5px;
  }

  .popup-menu li a{
    text-decoration:none;
    color:#000000;
  }

  .pop-menu li el-icon{
    margin:5px;
  }

  .popup-menu li button{
    background:none;
    border:none;
    color:#333;
    cursor:pointer;
  }

  .popup-menu li:hover{
    text-shadow: 0 2px 4px rgba(0,0,0,0.8);
    transform: translateX(-4px);
  }

  .main-content {
    margin-top: 64px;
    min-height: calc(100vh - 64px);
  }
  
  @media screen and (max-width: 1200px) {
    .nav-item {
      font-size: 14px;
      padding: 8px 8px;
    }
    
    .nav-links {
      gap: 12px;
    }
    
    .header-right {
      min-width: 300px;
    }
    
    .search-box input {
      width: 180px;
    }
    
    .search-box input:focus {
      width: 220px;
    }
  }
  
  @media screen and (max-width: 992px) {
    .logo span {
      display: none;
    }
    
    .logo {
      min-width: auto;
    }
    
    .header-right {
      min-width: 280px;
    }
  }

  
  </style>
  