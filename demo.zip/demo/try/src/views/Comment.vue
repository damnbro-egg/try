<template>
  <div>
    <div style="padding:10px;">
      <el-card>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.content" placeholder="请输入评论内容" prefix-icon="Search">
        </el-input>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.authorId" placeholder="请输入用户ID" prefix-icon="Search">
        </el-input>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.articleId" placeholder="请输入文章ID" prefix-icon="Search">
        </el-input>
        <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
        <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
      </el-card>
      <div class="card">
        <el-button type="primary" @click="handleAdd" plain>新增</el-button> 
        <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
      </div>
      <div class="card">
        <el-table :data="data.commentData" style="width: 100% ;" @selection-change="handleSelectionChange" >
          <el-table-column type="selection" width="55"/>
          <el-table-column prop="id" label="ID"/>
          <el-table-column prop="content" label="评论内容"/>
          <el-table-column prop="createDate" label="评论时间">
            <template #default="scope">
              {{ new Date(scope.row.createDate).toLocaleString() }}
            </template>
          </el-table-column>
          <el-table-column prop="articleId" label="文章ID"/>
          <el-table-column prop="authorId" label="作者ID"/>
          <el-table-column prop="parentId" label="父评论ID"/>
          <el-table-column prop="toUid" label="回复用户ID"/>
          <el-table-column prop="level" label="评论层级"/>
          <el-table-column fixed="right" label="操作" min-width="80px">
            <template #default="scope">
              <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
              <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
            </template>
          </el-table-column>
        </el-table>
        <div style="margin-top:10px;">
          <el-pagination
            v-model:current-page="data.currentPage"
            v-model:page-size="data.pageSize"
            :page-sizes="[5, 10, 20, 30, 40]"
            :small="data.small"
            :disabled="data.disabled"
            :background="data.background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="data.total"
            @size-change="load"
            @current-change="load"
          />
        </div>
      </div>

      <el-dialog title="评论信息" v-model="data.formVisible" width="30%" 
      :close-on-click-modal="false" destroy-on-close>
        <el-form ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
          <el-form-item label="评论内容" prop="content">
            <el-input v-model="data.form.content" placeholder="评论内容" type="textarea" :rows="4"/>
          </el-form-item>
          <el-form-item label="文章ID" prop="articleId">
            <el-input v-model="data.form.articleId" placeholder="文章ID"/>
          </el-form-item>
          <el-form-item label="作者ID" prop="authorId">
            <el-input v-model="data.form.authorId" placeholder="作者ID"/>
          </el-form-item>
          <el-form-item label="父评论ID" prop="parentId">
            <el-input v-model="data.form.parentId" placeholder="父评论ID"/>
          </el-form-item>
          <el-form-item label="回复用户ID" prop="toUid">
            <el-input v-model="data.form.toUid" placeholder="回复用户ID"/>
          </el-form-item>
          <el-form-item label="评论层级" prop="level">
            <el-input v-model="data.form.level" placeholder="评论层级"/>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="data.formVisible = false">取 消</el-button>
          <el-button type="primary" @click="save">保 存</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {Search, Refresh, Edit, Delete} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';

const data = reactive({
  content: null,
  authorId: null,
  articleId: null,
  commentData: [],
  currentPage: 1,
  pageSize: 12,
  total: 0,
  form: {},
  formVisible: false,
  ids: [],
  small: false,
  disabled: false,
  background: true,
  rules: {
    content: [
      {required: true, message: '请输入评论内容', trigger: 'blur'}
    ],
    articleId: [
      {required: true, message: '请输入文章ID', trigger: 'blur'}
    ],
    authorId: [
      {required: true, message: '请输入作者ID', trigger: 'blur'}
    ]
  }
})

const formRef = ref()

const load = () => {
  request.get('/comment/selectPage', {
    params: {
      page: data.currentPage,
      size: data.pageSize,
      content: data.content,
      authorId: data.authorId,
      articleId: data.articleId
    }
  }).then(res => {
    if (res.data && Array.isArray(res.data.records)) {
      data.commentData = res.data.records.filter(item => item);
    } else {
      data.commentData = [];
    }
    data.total = res.data.total;
  })
}

const reset = () => {
  data.content = null;
  data.authorId = null;
  data.articleId = null;
  load();
}

const handleAdd = () => {
  data.form = {};
  data.formVisible = true;
}

const handleUpdate = (row) => {
  data.form = JSON.parse(JSON.stringify(row));
  data.formVisible = true;
}

const save = () => {
  formRef.value.validate((valid) => {
    if (valid) {
      data.form.id ? update() : add();
    }
  })
}

const add = () => {
  request.post('/comment/add', data.form).then(res => {
    if (res.code == 200) {
      ElMessage.success('操作成功');
      data.formVisible = false;
      load();
    } else {
      ElMessage.error(res.msg);
    }
  })
}

const update = () => {
  request.put('/comment/update', data.form).then(res => {
    if (res.code == 200) {
      ElMessage.success('操作成功');
      data.formVisible = false;
      load();
    } else {
      ElMessage.error(res.msg);
    }
  })
}

const handleDelete = (id) => {
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？', '删除确认', {type: 'warning'}).then(() => {
    request.delete('/comment/deleteById/' + id).then(res => {
      if (res.code == 200) {
        ElMessage.success('操作成功');
        load();
      } else {
        ElMessage.error(res.msg);
      }
    })
  }).catch(() => {
    ElMessage.info('已取消删除');
  })
}

const handleSelectionChange = (selection) => {
  data.ids = selection.map(selection => selection.id);
}

const deleteBatch = () => {
  if (data.ids.length == 0) {
    ElMessage.warning('请选择要删除的数据');
    return;
  }
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？', '删除确认', {type: 'warning'}).then(() => {
    request.delete('/comment/deleteBatch', {data: data.ids}).then(res => {
      if (res.code == 200) {
        ElMessage.success('操作成功');
        load();
      } else {
        ElMessage.error(res.msg);
      }
    })
  }).catch(() => {
    ElMessage.info('已取消删除');
  })
}

// 初始化加载数据
load();
</script>

<style>
.card {
  box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  padding: 10px;
  margin-top: 10px;
}
</style>
