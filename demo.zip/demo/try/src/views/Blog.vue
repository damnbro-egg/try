<template>
  <div>
    <div style="padding:10px;">
      <el-card>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.name" placeholder="请输入标题" prefix-icon="Search">
        </el-input>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.categoryName" placeholder="请输入分类查询" prefix-icon="Search">
        </el-input>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.userName" placeholder="请输入用户名称查询" prefix-icon="Search">
        </el-input>
        <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
        <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
      </el-card>
      <div class="card">
        <el-button type="primary" @click="handleAdd" plain>新增</el-button> 
        <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
      </div>
      <div class="card">
        <el-table :data="data.blogData" style="width: 100% ;" @selection-change="handleSelectionChange" >
          <el-table-column type="selection" :selectable="selectable" width="55"/>
          <el-table-column prop="id" label="ID"/>
          <el-table-column prop="title" label="标题"/>
          <el-table-column prop="descr" label="简介"/>
          <el-table-column label="封面">
            <template v-slot="scope">
              <div style="display:flex; align-items:center;">
                  <el-image style="width:50px; height:50px; border-radius:5px" v-if="scope.row.cover"
                      :src="scope.row.cover" :preview-src-list="[scope.row.cover]"></el-image>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="tags" label="标签">
              <template v-slot="scope">
                <el-tag v-for="item in JSON.parse(scope.row.tags || '[]')" key="item" style="margin-right:5px;">{{item}}</el-tag>
              </template>
          </el-table-column>
          <el-table-column prop="userName" label="发布人"/>
          <el-table-column prop="date" label="发布日期"/>
          <el-table-column prop="readCount" label="浏览量" show-overflow-tooltip />
          <el-table-column prop="status" label="审核状态">
            <template #default="scope">
              <el-tag :type="scope.row.status === 1 ? 'success' : 'danger'">
                {{ scope.row.status === 1 ? '已通过' : '未通过' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="查看内容">
            <template v-slot="scope">
              <el-button @click="preview(scope.row.content)">查看内容</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="categoryName" label="分类名"/>
          <el-table-column fixed="right" label="操作" min-width="120px">
            <template #default="scope">
              <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
              <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
              <el-button 
                :type="scope.row.status === 1 ? 'warning' : 'success'" 
                :icon="scope.row.status === 1 ? 'Close' : 'Check'" 
                @click="handleStatusChange(scope.row)" 
                circle
              ></el-button>
            </template>
          </el-table-column>
        </el-table>
        <div style="margin-top:10px;">
          <el-pagination
            v-model:current-page="data.currentPage"
            v-model:page-size="data.pageSize"
            :page-sizes="[5, 10, 20, 30, 40]"
            :small="small"
            :disabled="disabled"
            :background="background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="data.total"
            @size-change="load"
            @current-change="load"
          />
        </div>
      </div>

      <el-dialog title="博客信息" v-model="data.formVisible" width="25%" 
      :close-on-click-modal="false" destroy-on-close>
        <el-form  ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
          <el-form-item label="标题" prop="title">
            <el-input v-model="data.form.title" placeholder="标题"/>
          </el-form-item>
          <el-form-item label="描述" prop="descr">
            <el-input v-model="data.form.descr" placeholder="描述"/>
          </el-form-item>
          <el-form-item label="封面" prop="cover">
            <el-upload
                class="avatar-uploader"
              :action="'http://localhost:8088/files/upload'"
              :headers="{ Authorization: 'Bearer ' + data.token }"
              :on-success="handleFileSuccess"
              list-type="picture"
            >
              <img v-if="data.form.cover" :src="data.form.cover" class="avatar" />
              <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
            </el-upload>
          </el-form-item>
          <el-form-item label="标签" prop="tags">
            <el-select v-model="data.tagsArr" multiple filterable allow-create default-first-option style="width:100%;">
                <el-option value="电车生活"></el-option>
                <el-option value="电车评测"></el-option>
                <el-option value="体验分享"></el-option>
                <el-option value="科普"></el-option>
                <el-option value="新闻快讯"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="日期" prop="date">
              <el-date-picker v-model="data.form.date" placeholder="日期"/>
          </el-form-item>
          <el-form-item label="阅读量" prop="readCount">
              <el-input v-model="data.form.readCount" placeholder="阅读量"/>
          </el-form-item>
          <el-form-item label="类别" prop="categoryId">
            <el-select v-model="data.form.categoryId" style="width:100%;">
              <el-option v-for="item in data.categoryList" :key="item.id" :value="item.id" :label="item.name"></el-option>
            </el-select>  
          </el-form-item>
          <el-form-item label="内容" prop="content">
            <div id="editor"></div>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="data.formVisible = false">取 消</el-button>
          <el-button type="primary" @click="save">保 存</el-button>
        </div>
      </el-dialog>
      <el-dialog title="文章内容" v-model="data.formVisible1" width="50%" :close-on-click-modal="false" destroy-on-close>
        <div class="preview-content" v-html="data.content">
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="data.formVisible1 = false">关 闭</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {Search, Refresh, Edit, Delete, Check, Close} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';
import '@wangeditor/editor/dist/css/style.css' 
import E from "wangeditor"
import hljs from 'highlight.js'

const data = reactive({
        token:localStorage.getItem('token')||'{}',
        name:null,
        categoryName:null,
        userName:null,
        blogData:[{}],
        currentPage: 1,
        pageSize: 12,
        total:0,
        form:{},
        formVisible:false,
        formVisible1:false,
        tagsArr:[],
        categoryList:[],
        ids:[],
        rules:{
          title:[
            {required:true,message:'请输入标题', trigger:'blur'}
          ],
        },
        editor:null,
        content:''
})

const formRef = ref()

function debounce(func, delay) {
let timer;
return function() {
  if (timer) {
    clearTimeout(timer);
  }
  timer = setTimeout(() => {
    func.apply(this, arguments);
    timer = null;
  }, delay);
};
}

const debouncedLoad = debounce(() => {
request.get('/blog/selectPage', {
  params: {
    page: data.currentPage,
    size: data.pageSize,
    title: data.name,
  }
}).then(res => {
  console.log(res);
  data.blogData = res.data.records;
  data.total = res.data.total;
})
request.get('/category/selectAll').then(res => {
  console.log('/category/selectAll');
  console.log(res);
  data.categoryList = res.data || []
});
}, 300);

debouncedLoad();

const load = () => {
  request.get('/blog/selectPage',{
    params:{
      page: data.currentPage,
      size: data.pageSize,
      title: data.name,
      categoryName: data.categoryName,
      userName: data.userName
    }
  }).then(res=>{
    console.log(res);
    console.log(data.token);
    if (res.data && Array.isArray(res.data.records)) {
          data.blogData = res.data.records.filter(item => item); // 过滤掉 null 值
      } else {
          data.blogData = [];
      }
    data.total = res.data.total;
  })
  request.get('/category/selectAll').then(res => {
    console.log('/category/selectAll');
    console.log(res);
    data.categoryList = res.data || []
  })
}

const reset = () => {
  data.name=null;
  data.categoryName=null;
  data.userName=null;
  load();
}

const handleAdd = ()=>{
  data.form = {};
  data.formVisible = true;
  setRichText();
}

const handleUpdate = (row)=>{
data.form = JSON.parse(JSON.stringify(row));
 data.formVisible=true;
 setRichText();
 setTimeout( ()=>{
    data.editor.txt.html(data.form.content)
 },0)
}

const preview =(content)=>{
  data.content = content;
  data.formVisible1 = true;
  console.log(data.content);
  console.log(data.formVisible1);
}

const save = ()=>{
  formRef.value.validate((valid)=>{
    if(valid){
      data.form.content = data.editor.txt.html();
      data.form.tags = JSON.stringify(data.tagsArr);
      console.log('标签转换');
      console.log(data.form.tags);
      console.log(data.editor)
      data.form.id? update() : add();
    }
  })
}

const add=()=>{
  request.post('/blog/add', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const update=()=>{
  request.put('/blog/update', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const handleDelete = (id)=>{
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/blog/deleteById/'+id).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-|');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleSelectionChange = (selection)=>{

  data.ids = selection.map(selection=>selection.id);
  console.log(data.ids);
}

const deleteBatch = ()=>{
  if(data.ids.length == 0){
    ElMessage.warning('请选择要删除的数据');
    return;
  }
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/blog/deleteBatch',{data:data.ids}).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleFileSuccess = (res)=>{
  data.form.cover = res.data;
}

const setRichText = () => {
  setTimeout(() => {
    data.editor = new E(`#editor`);
    data.editor.highlight = hljs;
    data.editor.config.uploadImgServer ='http://localhost:8088/files/editor/upload';
    data.editor.config.uploadFileName = 'file';
    data.editor.config.uploadImgHeaders = {
      Authorization: 'Bearer ' + localStorage.getItem('token') || '{}'
    };
    data.editor.config.uploadImgParams = {
      type:'img',
    };
    data.editor.create();
  }, 0);
}

// 处理审核状态变更
const handleStatusChange = (row) => {
  const newStatus = row.status === 1 ? 0 : 1;
  const statusText = newStatus === 1 ? '通过' : '不通过';
  
  ElMessageBox.confirm(`确定要将该博客标记为${statusText}吗？`, '审核确认', {
    type: 'warning'
  }).then(() => {
    request.put('/blog/updateStatus', {
      id: row.id,
      status: newStatus
    }).then(res => {
      if (res.code == 200) {
        ElMessage.success('审核状态更新成功');
        load();
      } else {
        ElMessage.error(res.msg || '操作失败');
      }
    }).catch(error => {
      console.error('更新状态失败:', error);
      ElMessage.error('操作失败');
    });
  }).catch(() => {
    ElMessage.info('已取消操作');
  });
};

</script>

<style>
  .card{
    box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
    border-radius:5px;
    padding:10px;
    margin-top:10px;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed var(--el-border-color);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: var(--el-transition-duration-fast);
  }

  .avatar-uploader .el-upload:hover {
    border-color: var(--el-color-primary);
  }

  .el-icon.avatar-uploader-icon,.avatar{
    font-size: 28px;
    color: #8c939d;
    width: 80px;
    height: 80px;
    text-align: center;
  }

  /* 预览内容样式 */
  .preview-content {
    max-height: 70vh;
    overflow-y: auto;
    padding: 0 20px;
  }

  .preview-content img {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 10px 0;
  }

  .preview-content p {
    margin: 10px 0;
  }

  /* 自定义滚动条样式 */
  .preview-content::-webkit-scrollbar {
    width: 6px;
  }

  .preview-content::-webkit-scrollbar-thumb {
    background-color: #dcdfe6;
    border-radius: 3px;
  }

  .preview-content::-webkit-scrollbar-track {
    background-color: #f5f7fa;
    border-radius: 3px;
  }
</style>
