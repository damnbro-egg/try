<template>
  <div>
    <div style="padding:10px;">
      <el-card>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.name" placeholder="请输入车名" prefix-icon="Search">
        </el-input>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.brand" placeholder="请输入品牌" prefix-icon="Search">
        </el-input>
        <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
        <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
      </el-card>
      <div class="card">
        <el-button type="primary" @click="handleAdd" plain>新增</el-button>
        <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
      </div>
      <div class="card">
        <el-table :data="data.carData" style="width: 100%" @selection-change="handleSelectionChange" >
          <el-table-column type="selection" :selectable="selectable" width="55"/>
          <el-table-column prop="id" label="ID"/>
          <el-table-column prop="name" label="车名"/>
          <el-table-column prop="brand" label="品牌"/>
          <el-table-column prop="model" label="型号"/>
          <el-table-column prop="carType" label="车型"/>
          <el-table-column prop="powerType" label="动力类型"/>
          <el-table-column prop="price" label="价格"/>
          <el-table-column label="图片">
            <template v-slot="scope">
              <div style="display:flex; align-items:center;">
                <el-image style="width:50px; height:50px; border-radius:5px" v-if="scope.row.carPicture"
                    :src="scope.row.carPicture" :preview-src-list="[scope.row.carPicture]"></el-image>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="status" label="状态">
            <template #default="scope">
              <el-tag :type="scope.row.status == 1 ? 'success' : 'danger'">
                {{ scope.row.status == 1 ? '已上架' : '未上架' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column fixed="right" label="操作" min-width="120px">
            <template #default="scope">
              <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
              <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
              <el-button 
                :type="scope.row.status == 1 ? 'warning' : 'success'" 
                :icon="scope.row.status == 1 ? 'Close' : 'Check'" 
                @click="handleStatusChange(scope.row)" 
                circle
              ></el-button>
            </template>
          </el-table-column>
        </el-table>
        <div style="margin-top:10px;">
          <el-pagination
            v-model:current-page="data.currentPage"
            v-model:page-size="data.pageSize"
            :page-sizes="[5, 10, 20, 30, 40]"
            :small="small"
            :disabled="disabled"
            :background="background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="data.total"
            @size-change="load"
            @current-change="load"
          />
        </div>
      </div>

      <el-dialog title="车辆信息" v-model="data.formVisible" width="50%" 
      :close-on-click-modal="false" destroy-on-close>
        <el-form ref="formRef" :rules="data.rules" :model="data.form" label-width="100px" style="padding:20px 20px 0 0">
          <el-form-item label="车名" prop="name">
            <el-input v-model="data.form.name" placeholder="车名"/>
          </el-form-item>
          <el-form-item label="品牌" prop="brand">
            <el-input v-model="data.form.brand" placeholder="品牌"/>
          </el-form-item>
          <el-form-item label="型号" prop="model">
            <el-input v-model="data.form.model" placeholder="型号"/>
          </el-form-item>
          <el-form-item label="车型" prop="carType">
            <el-input v-model="data.form.carType" placeholder="车型"/>
          </el-form-item>
          <el-form-item label="动力类型" prop="powerType">
            <el-input v-model="data.form.powerType" placeholder="动力类型"/>
          </el-form-item>
          <el-form-item label="价格" prop="price">
            <el-input v-model="data.form.price" placeholder="价格"/>
          </el-form-item>
          <el-form-item label="图片" prop="carPicture">
            <el-upload
              class="avatar-uploader"
              :action="'http://localhost:8088/files/upload'"
              :headers="{ Authorization: 'Bearer ' + data.token }"
              :on-success="handleFileSuccess"
              list-type="picture"
            >
              <img v-if="data.form.carPicture" :src="data.form.carPicture" class="avatar" />
              <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
            </el-upload>
          </el-form-item>
          <el-form-item label="电机类型" prop="motorType">
            <el-input v-model="data.form.motorType" placeholder="电机类型"/>
          </el-form-item>
          <el-form-item label="电机功率" prop="motorPower">
            <el-input v-model="data.form.motorPower" placeholder="电机功率"/>
          </el-form-item>
          <el-form-item label="扭矩" prop="torque">
            <el-input v-model="data.form.torque" placeholder="扭矩"/>
          </el-form-item>
          <el-form-item label="加速时间" prop="acceleration">
            <el-input v-model="data.form.acceleration" placeholder="加速时间"/>
          </el-form-item>
          <el-form-item label="最高速度" prop="topSpeed">
            <el-input v-model="data.form.topSpeed" placeholder="最高速度"/>
          </el-form-item>
          <el-form-item label="电池类型" prop="batteryType">
            <el-input v-model="data.form.batteryType" placeholder="电池类型"/>
          </el-form-item>
          <el-form-item label="电池容量" prop="batteryCapacity">
            <el-input v-model="data.form.batteryCapacity" placeholder="电池容量"/>
          </el-form-item>
          <el-form-item label="续航里程" prop="range">
            <el-input v-model="data.form.range" placeholder="续航里程"/>
          </el-form-item>
          <el-form-item label="快充时间" prop="chargeTime">
            <el-input v-model="data.form.chargeTime" placeholder="快充时间"/>
          </el-form-item>
          <el-form-item label="慢充时间" prop="slowChargeTime">
            <el-input v-model="data.form.slowChargeTime" placeholder="慢充时间"/>
          </el-form-item>
          <el-form-item label="车长" prop="length">
            <el-input v-model="data.form.length" placeholder="车长"/>
          </el-form-item>
          <el-form-item label="车宽" prop="width">
            <el-input v-model="data.form.width" placeholder="车宽"/>
          </el-form-item>
          <el-form-item label="车高" prop="height">
            <el-input v-model="data.form.height" placeholder="车高"/>
          </el-form-item>
          <el-form-item label="轴距" prop="wheelbase">
            <el-input v-model="data.form.wheelbase" placeholder="轴距"/>
          </el-form-item>
          <el-form-item label="车重" prop="weight">
            <el-input v-model="data.form.weight" placeholder="车重"/>
          </el-form-item>
          <el-form-item label="座位数" prop="seatNum">
            <el-input v-model="data.form.seatNum" placeholder="座位数"/>
          </el-form-item>
          <el-form-item label="驱动方式" prop="driveType">
            <el-input v-model="data.form.driveType" placeholder="驱动方式"/>
          </el-form-item>
          <el-form-item label="发布日期" prop="releaseDate">
            <el-date-picker v-model="data.form.releaseDate" placeholder="发布日期"/>
          </el-form-item>
          <el-form-item label="保修期" prop="warranty">
            <el-input v-model="data.form.warranty" placeholder="保修期"/>
          </el-form-item>
          <el-form-item label="描述" prop="description">
            <el-input type="textarea" v-model="data.form.description" placeholder="描述"/>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="data.formVisible = false">取 消</el-button>
          <el-button type="primary" @click="save">保 存</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {Search, Refresh, Edit, Delete, Check, Close, Plus} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';

const data = reactive({
        token:localStorage.getItem('token')||'{}',
        name:null,
        brand:null,
        carData:[{}],
        currentPage: 1,
        pageSize: 12,
        total:0,
        form:{},
        formVisible:false,
        ids:[],
        rules:{
          name:[
            {required:true,message:'请输入车名', trigger:'blur'}
          ],
          brand:[
            {required:true,message:'请输入品牌', trigger:'blur'}
          ]
        }
})

const formRef = ref()

const load = () => {
  request.get('/car1/selectPage',{
    params:{
      page: data.currentPage,
      size: data.pageSize,
      name: data.name,
      brand: data.brand
    }
  }).then(res=>{
    console.log(res);
    data.carData = res.data.records;
    data.total = res.data.total;
  })
}

load()

const reset = () => {
  data.name=null;
  data.brand=null;
  load();
}

const handleAdd = ()=>{
  data.form = {};
  data.formVisible = true;
}

const handleUpdate = (row)=>{
  data.form = JSON.parse(JSON.stringify(row));
  data.formVisible=true;
}

const save = ()=>{
  formRef.value.validate((valid)=>{
    if(valid){
      data.form.id? update() : add();
    }
  })
}

const add=()=>{
  request.post('/car1/add', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const update=()=>{
  request.put('/car1/update', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const handleDelete = (id)=>{
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/car1/deleteById/'+id).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-|');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleSelectionChange = (selection)=>{
  data.ids = selection.map(selection=>selection.id);
  console.log(data.ids);
}

const deleteBatch = ()=>{
  if(data.ids.length == 0){
    ElMessage.warning('请选择要删除的数据');
    return;
  }
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/car1/deleteBatch',{data:data.ids}).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleFileSuccess = (res)=>{
  data.form.carPicture = res.data;
}

// 处理状态变更
const handleStatusChange = (row) => {
  const newStatus = row.status == 1 ? 0 : 1;
  const statusText = newStatus == 1 ? '上架' : '下架';
  
  ElMessageBox.confirm(`确定要将该车辆标记为${statusText}吗？`, '状态确认', {
    type: 'warning'
  }).then(() => {
    request.put('/car1/updateStatus', {
      id: row.id,
      status: newStatus
    }).then(res => {
      if (res.code == 200) {
        ElMessage.success('状态更新成功');
        load();
      } else {
        ElMessage.error(res.msg || '操作失败');
      }
    }).catch(error => {
      console.error('更新状态失败:', error);
      ElMessage.error('操作失败');
    });
  }).catch(() => {
    ElMessage.info('已取消操作');
  });
};
</script>

<style>
  .card{
    box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
    border-radius:5px;
    padding:10px;
    margin-top:10px;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed var(--el-border-color);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: var(--el-transition-duration-fast);
  }

  .avatar-uploader .el-upload:hover {
    border-color: var(--el-color-primary);
  }

  .el-icon.avatar-uploader-icon,.avatar{
    font-size: 28px;
    color: #8c939d;
    width: 80px;
    height: 80px;
    text-align: center;
  }
</style>
