<template>
    <div>
      <div style="padding:10px;">
        <el-card>
          <el-input style="width: 240px; margin-right:5px; " v-model="data.name" placeholder="请输入活动名称" prefix-icon="Search">
          </el-input>
          <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
          <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
        </el-card>
        <div class="card">
          <el-button type="primary" @click="handleAdd" plain>新增</el-button> 
          <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
        </div>
        <div class="card">
          <el-table :data="data.activityData" style="width: 100% ;" @selection-change="handleSelectionChange" >
            <el-table-column type="selection" :selectable="selectable" width="55"/>
            <el-table-column prop="id" label="ID"/>
            <el-table-column prop="name" label="名称"/>
            <el-table-column prop="descr" label="简介"/>
            <el-table-column label="查看内容">
              <template v-slot="scope">
                <el-button @click="preview(scope.row.content)">查看内容</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="start" label="开始时间"/>
            <el-table-column prop="end" label="结束时间"/>
            <el-table-column prop="form" label="活动形式"/>
            <el-table-column prop="address" label="地点"/>
            <el-table-column prop="host" label="主办人"/>
            <el-table-column prop="read_count" label="阅读量"/>
            <el-table-column label="封面">
              <template v-slot="scope">
                <div style="display:flex; align-items:center;">
                    <el-image style="width:50px; height:50px; border-radius:5px; z-index:300px;" v-if="scope.row.cover"
                        :src="scope.row.cover" :preview-src-list="[scope.row.cover]"></el-image>
                </div>
              </template>
            </el-table-column>
            <el-table-column fixed="right" label="操作" min-width="80px">
              <template #default="scope">
                <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
                <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
              </template>
            </el-table-column>
          </el-table>
          <div style="margin-top:10px;">
            <el-pagination
              v-model:current-page="data.currentPage"
              v-model:page-size="data.pageSize"
              :page-sizes="[5, 10, 20, 30, 40]"
              :small="small"
              :disabled="disabled"
              :background="background"
              layout="total, sizes, prev, pager, next, jumper"
              :total="data.total"
              @size-change="load"
              @current-change="load"
            />
          </div>
        </div>
  
        <el-dialog title="活动信息" v-model="data.formVisible" width="25%" 
        :close-on-click-modal="false" destroy-on-close>
          <el-form  ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
            <el-form-item label="名字" prop="name">
              <el-input v-model="data.form.name" placeholder="名字"/>
            </el-form-item>
            <el-form-item label="描述" prop="descr">
              <el-input v-model="data.form.descr" placeholder="描述"/>
            </el-form-item>
            <el-form-item label="封面" prop="cover">
              <el-upload
                  class="avatar-uploader"
                :action="'http://localhost:8088/files/upload'"
                :headers="{ Authorization: 'Bearer ' + data.token }"
                :on-success="handleFileSuccess"
                list-type="picture"
              >
                <img v-if="data.form.cover" :src="data.form.cover" class="avatar" />
                <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
              </el-upload>
            </el-form-item>
            <el-form-item label="开始时间" prop="start">
                <el-date-picker v-model="data.form.start" placeholder="开始"/>
            </el-form-item>
            <el-form-item label="结束时间" prop="end">
                <el-date-picker v-model="data.form.end" placeholder="结束"/>
            </el-form-item>
            <el-form-item label="活动形式" prop="form">
                <el-input v-model="data.form.form" placeholder="活动形式"/>
            </el-form-item>
            <el-form-item label="地址" prop="address">
                <el-input v-model="data.form.address" placeholder="地址"/>
            </el-form-item>
            <el-form-item label="主办方" prop="host">
                <el-input v-model="data.form.host" placeholder="主办方"/>
            </el-form-item>
            <el-form-item label="阅读量" prop="readCount">
                <el-input v-model="data.form.readCount" placeholder="阅读量"/>
            </el-form-item>
            <el-form-item label="内容" prop="content">
            <div id="editor"></div>
          </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="data.formVisible = false">取 消</el-button>
            <el-button type="primary" @click="save">保 存</el-button>
          </div>
        </el-dialog>
        <el-dialog title="活动内容" v-model="data.formVisible1" width="50%" :close-on-click-modal="false" destroy-on-close>
          <div class="w-e-text">
            <div v-html="data.content"></div>
            </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="data.formVisible1 = false">关 闭</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </template>
  
  <script setup>
  import {reactive,ref} from 'vue';
  import {Search, Refresh, Edit, Delete} from '@element-plus/icons-vue';
  import request from '@/utils/request';
  import { ElMessage } from 'element-plus';
  import { ElMessageBox } from 'element-plus';
  import '@wangeditor/editor/dist/css/style.css' 
  import E from "wangeditor"
  import hljs from 'highlight.js'
  
  const data = reactive({
          token:localStorage.getItem('token')||'{}',
          name:null,
          userName:null,
          activityData:[{}],
          currentPage: 1,
          pageSize: 12,
          total:0,
          form:{},
          formVisible:false,
          formVisible1:false,
          tagsArr:[],
          categoryList:[],
          ids:[],
          rules:{
            name:[
              {required:true,message:'请输入活动名', trigger:'blur'}
            ],
            start:[
              {required:true,message:'请输入开始时间', trigger:'blur'}
            ],
          },
          editor:null,
          content:''
  })
  
  const formRef = ref()
  
  function debounce(func, delay) {
  let timer;
  return function() {
    if (timer) {
      clearTimeout(timer);
    }
    timer = setTimeout(() => {
      func.apply(this, arguments);
      timer = null;
    }, delay);
  };
  }
  
  const debouncedLoad = debounce(() => {
  request.get('/activity/selectPage', {
    params: {
      page: data.currentPage,
      size: data.pageSize,
      name: data.name,
    }
  }).then(res => {
    console.log(res);
    console.log(data.token);
    data.activityData = res.data.records;
    data.total = res.data.total;
  })
  }, 300);
  
  debouncedLoad();
  
  const load = () => {
    request.get('/activity/selectPage',{
      params:{
        page: data.currentPage,
        size: data.pageSize,
        name: data.name,
      }
    }).then(res=>{
      console.log(res);
      console.log(data.token);
      if (res.data && Array.isArray(res.data.records)) {
            data.activityData = res.data.records.filter(item => item); // 过滤掉 null 值
        } else {
            data.activityData = [];
        }
      data.total = res.data.total;
    })
  }
  
  const reset = () => {
    data.name=null;
    data.categoryName=null;
    data.userName=null;
    load();
  }
  
  const handleAdd = ()=>{
    data.form = {};
    data.formVisible = true;
    setRichText();
  }
  
  const handleUpdate = (row)=>{
  data.form = JSON.parse(JSON.stringify(row));
   data.formVisible=true;
   setRichText();
   setTimeout( ()=>{
      data.editor.txt.html(data.form.content)
   },0)
  }
  
  const preview =(content)=>{
    data.content = content;
    data.formVisible1 = true;
    console.log(data.content);
    console.log(data.formVisible1);
  }
  
  const save = ()=>{
    formRef.value.validate((valid)=>{
      if(valid){
        data.form.content = data.editor.txt.html();
        console.log(data.editor);
        console.log('editor内容');
        console.log(data.form);
        console.log('form内容');
        data.form.id? update() : add();
      }
    })
  }
  
  const add=()=>{
    request.post('/activity/add', data.form).then(res=>{
      console.log(res);
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        data.formVisible = false;
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }
  
  const update=()=>{
    request.put('/activity/update', data.form).then(res=>{
      console.log(res);
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        data.formVisible = false;
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }
  
  const handleDelete = (id)=>{
    ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
      request.delete('/activity/deleteById/'+id).then(res=>{
        if(res.code == 200){
          ElMessage.success('-操作成功-');
          load();
        }else{
          ElMessage.error('-'+res.msg+'-|');
        }
      })
    }).catch(()=>{
      ElMessage.info('已取消删除');
    })
  }
  
  const handleSelectionChange = (selection)=>{
  
    data.ids = selection.map(selection=>selection.id);
    console.log(data.ids);
  }
  
  const deleteBatch = ()=>{
    if(data.ids.length == 0){
      ElMessage.warning('请选择要删除的数据');
      return;
    }
    ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
      request.delete('/activity/deleteBatch',{data:data.ids}).then(res=>{
        if(res.code == 200){
          ElMessage.success('-操作成功-');
          load();
        }else{
          ElMessage.error('-'+res.msg+'-');
        }
      })
    }).catch(()=>{
      ElMessage.info('已取消删除');
    })
  }
  
  const handleFileSuccess = (res)=>{
    data.form.cover = res.data;
  }
  
  const setRichText = () => {
    // 确保在 DOM 渲染完成后初始化编辑器
    setTimeout(() => {
      data.editor = new E(`#editor`);
      data.editor.highlight = hljs;
      // 这里需要正确设置你的 baseUrl
      data.editor.config.uploadImgServer ='http://localhost:8088/files/editor/upload';
      data.editor.config.uploadFileName = 'file';
      data.editor.config.uploadImgHeaders = {
        Authorization: 'Bearer ' + localStorage.getItem('token') || '{}'
      };
      data.editor.config.uploadImgParams = {
        type:'img',
      };
      data.editor.create();
    }, 0);
  }
  
  </script>
  
  <style>
    .card{
      box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
      border-radius:5px;
      padding:10px;
      margin-top:10px;
    }
    .avatar-uploader .el-upload {
      border: 1px dashed var(--el-border-color);
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      transition: var(--el-transition-duration-fast);
    }
  
    .avatar-uploader .el-upload:hover {
      border-color: var(--el-color-primary);
    }
  
    .el-icon.avatar-uploader-icon,.avatar{
      font-size: 28px;
      color: #8c939d;
      width: 80px;
      height: 80px;
      text-align: center;
    }

    .w-e-text img{
        width:100% !important;
    }
  
  </style>
  