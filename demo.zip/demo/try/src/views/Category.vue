<template>
    <div>
      <div style="padding:10px;">
        <el-card>
          <el-input style="width: 240px; margin-right:5px; " v-model="data.name" placeholder="请输入" prefix-icon="Search">
          </el-input>
          <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
          <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
        </el-card>
        <div class="card">
          <el-button type="primary" @click="handleAdd" plain>新增</el-button> 
          <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
        </div>
        <div class="card">
          <el-table :data="data.categoryData" style="width: 100%" @selection-change="handleSelectionChange" >
            <el-table-column type="selection" :selectable="selectable" width="55"/>
            <el-table-column prop="id" label="ID"/>
            <el-table-column prop="name" label="分类名称"/>
            <el-table-column fixed="right" label="操作" min-width="80px">
              <template #default="scope">
                <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
                <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
              </template>
            </el-table-column>
          </el-table>
          <div style="margin-top:10px;">
            <el-pagination
              v-model:current-page="data.currentPage"
              v-model:page-size="data.pageSize"
              :page-sizes="[5, 10, 20, 30, 40]"
              :small="small"
              :disabled="disabled"
              :background="background"
              layout="total, sizes, prev, pager, next, jumper"
              :total="data.total"
              @size-change="load"
              @current-change="load"
            />
          </div>
        </div>
  
        <el-dialog title="类别信息" v-model="data.formVisible" width="25%" 
        :close-on-click-modal="false" destroy-on-close>
          <el-form  ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
            <el-form-item label="分类名称" prop="name">
              <el-input v-model="data.form.name" placeholder="分类名称"/>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="data.formVisible = false">取 消</el-button>
            <el-button type="primary" @click="save">保 存</el-button>
          </div>
        </el-dialog>
        
      </div>
    </div>
  </template>
  
  <script setup>
  import {reactive,ref} from 'vue';
  import {Search, Refresh, Edit, Delete} from '@element-plus/icons-vue';
  import request from '@/utils/request';
  import { ElMessage } from 'element-plus';
  import { ElMessageBox } from 'element-plus';
  
  const data = reactive({
          token:localStorage.getItem('token')||'{}',
          name:null,
          categoryData:[{}],
          currentPage: 1,
          pageSize: 12,
          total:0,
          form:{role:'USER'},
          formVisible:false,
          ids:[],
          rules:{
            name:[
              {required:true,message:'请输入昵称', trigger:'blur'}
            ],
          }
  })
  
  
  
  const formRef = ref()
  
  const load = () => {
    request.get('/category/selectPage',{
      params:{
        page: data.currentPage,
        size: data.pageSize,
        name: data.name,
      }
    }).then(res=>{
      console.log(res);
      console.log(data.token);
      data.categoryData = res.data.records;
      data.total = res.data.total;
    })
  }
  
  load()
  
  const reset = () => {
    data.name=null;
    load();
  }
  
  const handleAdd = ()=>{
    data.formVisible = true;
    data.form = {};
  }
  
  const save = ()=>{
    formRef.value.validate((valid)=>{
      if(valid){
        data.form.id? update() : add();
      }
    })
  }
  
  const add=()=>{
    request.post('/category/add', data.form).then(res=>{
      console.log(res);
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        data.formVisible = false;
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }
  
  const update=()=>{
    request.put('/category/update', data.form).then(res=>{
      console.log(res);
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        data.formVisible = false;
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }
  
  const handleUpdate = (row)=>{
   data.formVisible=true;
   data.form = JSON.parse(JSON.stringify(row));
  }
  
  const handleDelete = (id)=>{
    ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
      request.delete('/category/deleteById/'+id).then(res=>{
        if(res.code == 200){
          ElMessage.success('-操作成功-');
          load();
        }else{
          ElMessage.error('-'+res.msg+'-|');
        }
      })
    }).catch(()=>{
      ElMessage.info('已取消删除');
    })
  }
  
  const handleSelectionChange = (selection)=>{
  
    data.ids = selection.map(selection=>selection.id);
    console.log(data.ids);
  }
  
  const deleteBatch = ()=>{
    if(data.ids.length == 0){
      ElMessage.warning('请选择要删除的数据');
      return;
    }
    ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
      request.delete('/category/deleteBatch',{data:data.ids}).then(res=>{
        if(res.code == 200){
          ElMessage.success('-操作成功-');
          load();
        }else{
          ElMessage.error('-'+res.msg+'-');
        }
      })
    }).catch(()=>{
      ElMessage.info('已取消删除');
    })
  }
  
  const handleFileSuccess = (res)=>{
    data.form.avatar = res.data;
  }
  </script>
  
  <style>
    .card{
      box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
      border-radius:5px;
      padding:10px;
      margin-top:10px;
    }
    .avatar-uploader .el-upload {
      border: 1px dashed var(--el-border-color);
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      transition: var(--el-transition-duration-fast);
    }
  
    .avatar-uploader .el-upload:hover {
      border-color: var(--el-color-primary);
    }
  
    .el-icon.avatar-uploader-icon,.avatar{
      font-size: 28px;
      color: #8c939d;
      width: 80px;
      height: 80px;
      text-align: center;
    }
  </style>
  