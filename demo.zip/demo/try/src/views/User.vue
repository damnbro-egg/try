<template>
  <div>
    <div style="padding:10px;">
      <el-card>
        <el-input style="width: 240px; margin-right:5px; " v-model="data.name" placeholder="请输入" prefix-icon="Search">
        </el-input>
        <el-button type="primary" :icon="Search" @click="load" >搜索</el-button>
        <el-button type="warning" :icon="Refresh" @click="reset">重置</el-button>
      </el-card>
      <div class="card">
        <el-button type="primary" @click="handleAdd" plain>新增</el-button> 
        <el-button type="warning" @click="deleteBatch" plain>批量删除</el-button>
      </div>
      <div class="card">
        <el-table :data="data.userData" style="width: 100%" @selection-change="handleSelectionChange" >
          <el-table-column type="selection" :selectable="selectable" width="55"/>
          <el-table-column label="头像">
            <template #default="scope">
              <img :src="scope.row.avatar" style="width:40px; height:40px; border-radius:50%">
            </template>
          </el-table-column>
          <el-table-column prop="id" label="ID"/>
          <el-table-column prop="username" label="账号"/>
          <el-table-column prop="password" label="密码"/>
          <el-table-column prop="name" label="昵称"/>
          <el-table-column prop="role" label="身份"/>
          <el-table-column prop="sex" label="性别"/>
          <el-table-column prop="phone" label="电话"/>
          <el-table-column prop="email" label="邮件"/>
          <el-table-column prop="info" label="个人简介" show-overflow-tooltip />
          <el-table-column prop="birth" label="生日"/>
          <el-table-column fixed="right" label="操作" min-width="80px">
            <template #default="scope">
              <el-button type="primary" :icon="Edit" @click="handleUpdate(scope.row)" circle></el-button>
              <el-button type="danger" :icon="Delete" @click="handleDelete(scope.row.id)" circle></el-button>
            </template>
          </el-table-column>
        </el-table>
        <div style="margin-top:10px;">
          <el-pagination
            v-model:current-page="data.currentPage"
            v-model:page-size="data.pageSize"
            :page-sizes="[5, 10, 20, 30, 40]"
            :small="small"
            :disabled="disabled"
            :background="background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="data.total"
            @size-change="load"
            @current-change="load"
          />
        </div>
      </div>

      <el-dialog title="管理员信息" v-model="data.formVisible" width="25%" 
      :close-on-click-modal="false" destroy-on-close>
        <el-form  ref="formRef" :rules="data.rules" :model="data.form" label-width="80px" style="padding:20px 20px 0 0">
          <el-form-item label="账号" prop="username">
            <el-input v-model="data.form.username" placeholder="账号"/>
          </el-form-item>
          <el-form-item label="密码" prop="password">
            <el-input v-model="data.form.password" placeholder="密码"/>
          </el-form-item>
          <el-form-item label="昵称" prop="name">
            <el-input v-model="data.form.name" placeholder="昵称"/>
          </el-form-item>
          <el-form-item label="头像" prop="avatar">
            <el-upload
                class="avatar-uploader"
              :action="'http://localhost:8088/files/upload'"
              :headers="{ Authorization: 'Bearer ' + data.token }"
              :on-success="handleFileSuccess"
              list-type="picture"
            >
              <img v-if="data.form.avatar" :src="data.form.avatar" class="avatar" />
              <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
            </el-upload>
          </el-form-item>
          <el-form-item label="身份" prop="role">
            <el-radio-group v-model="data.form.role">
              <el-radio value="ADMIN" label="管理员" disabled></el-radio>
              <el-radio value="USER" label="用户"></el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="性别" prop="sex">
            <el-radio-group v-model="data.form.sex">
              <el-radio value="male" label="男"></el-radio>
              <el-radio value="female" label="女"></el-radio> 
            </el-radio-group> 
          </el-form-item>
          <el-form-item label="电话" prop="phone">
            <el-input v-model="data.form.phone" placeholder="电话"/>
          </el-form-item>
          <el-form-item label="邮件" prop="email">
            <el-input v-model="data.form.email" placeholder="邮件"/>
          </el-form-item>
          <el-form-item label="个人简介" prop="info">
            <el-input :rows="3" type="textarea" v-model="data.form.info" placeholder="个人简介"></el-input> 
          </el-form-item>
          <el-form-item label="生日" prop="birth">
            <el-date-picker value-format="YYYY-MM-DD" format="YYYY-MM-DD" v-model="data.form.birth"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="data.formVisible = false">取 消</el-button>
          <el-button type="primary" @click="save">保 存</el-button>
        </div>
      </el-dialog>
      
    </div>
  </div>
</template>

<script setup>
import {reactive,ref} from 'vue';
import {Search, Refresh, Edit, Delete} from '@element-plus/icons-vue';
import request from '@/utils/request';
import { ElMessage } from 'element-plus';
import { ElMessageBox } from 'element-plus';

const data = reactive({
        token:localStorage.getItem('token')||'{}',
        name:null,
        userData:[{}],
        currentPage: 1,
        pageSize: 12,
        total:0,
        form:{role:'USER'},
        formVisible:false,
        ids:[],
        rules:{
          username:[
            {required:true, message:'请输入账号', trigger:'blur'}
          ],
          name:[
            {required:true,message:'请输入昵称', trigger:'blur'}
          ],
        }
})



const formRef = ref()

const load = () => {
  request.get('/user/selectPage',{
    params:{
      page: data.currentPage,
      size: data.pageSize,
      username: data.name,
    }
  }).then(res=>{
    console.log(res);
    console.log(data.token);
    data.userData = res.data.records;
    data.total = res.data.total;
  })
}

load()

const reset = () => {
  data.name=null;
  load();
}

const handleAdd = ()=>{
  data.formVisible = true;
  data.form = {};
}

const save = ()=>{
  formRef.value.validate((valid)=>{
    if(valid){
      data.form.id? update() : add();
    }
  })
}

const add=()=>{
  request.post('/user/add', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const update=()=>{
  request.put('/user/update', data.form).then(res=>{
    console.log(res);
    if(res.code == 200){
      ElMessage.success('-操作成功-');
      data.formVisible = false;
      load();
    }else{
      ElMessage.error('-'+res.msg+'-');
    }
  })
}

const handleUpdate = (row)=>{
 data.formVisible=true;
 data.form = JSON.parse(JSON.stringify(row));
}

const handleDelete = (id)=>{
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/user/deleteById/'+id).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-|');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleSelectionChange = (selection)=>{

  data.ids = selection.map(selection=>selection.id);
  console.log(data.ids);
}

const deleteBatch = ()=>{
  if(data.ids.length == 0){
    ElMessage.warning('请选择要删除的数据');
    return;
  }
  ElMessageBox.confirm('删除数据无法恢复，您确定删除吗？','删除确认',{type:'warning'}).then(()=>{
    request.delete('/user/deleteBatch',{data:data.ids}).then(res=>{
      if(res.code == 200){
        ElMessage.success('-操作成功-');
        load();
      }else{
        ElMessage.error('-'+res.msg+'-');
      }
    })
  }).catch(()=>{
    ElMessage.info('已取消删除');
  })
}

const handleFileSuccess = (res)=>{
  data.form.avatar = res.data;
}
</script>

<style>
  .card{
    box-shadow: 5px 5px 10px 0 rgba(0, 0, 0, 0.1);
    border-radius:5px;
    padding:10px;
    margin-top:10px;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed var(--el-border-color);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: var(--el-transition-duration-fast);
  }

  .avatar-uploader .el-upload:hover {
    border-color: var(--el-color-primary);
  }

  .el-icon.avatar-uploader-icon,.avatar{
    font-size: 28px;
    color: #8c939d;
    width: 80px;
    height: 80px;
    text-align: center;
  }
</style>
