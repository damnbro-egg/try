import { createRouter, createWebHistory } from 'vue-router';
import HomePage from '../components/HomePage.vue'
import Car from '../components/Car.vue'
import Community from '../components/Community.vue'
import Back from '../components/Back.vue'
import Data from '../views/Data.vue'
import User from '../views/User.vue'
import Admin from '../views/Admin.vue'
import Category from '../views/Category.vue'
import Comment from '../views/Comment.vue'
import Blog from '../views/Blog.vue'
import Login from '../components/Login.vue'
import Register from '../components/Register.vue'
import Main from '../components/Main.vue'
import Me from '../components/Me.vue'
import Publish from '../components/Publish.vue'
import { jwtDecode } from 'jwt-decode';
import News from '../components/news.vue'
import Password from '../components/Password.vue';
import Activity from '@/views/Activity.vue';
import { IconComponentMap } from 'element-plus';
import Blog1 from '../components/Blog1.vue'
import Car1 from '../components/Car1.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
        { path:'/', redirect: '/login' },
        { 
            path: '/', 
            name: 'Main',
            component: Main, 
            children: [
                { path: 'homePage', name: 'HomePageInMain', component: HomePage },
                { path: 'car', name: 'CarInMain', component: Car },
                { path: 'community', name: 'CommunityInMain', component: Community },
                { path: 'news', name:'NewsInMain', component: News },
                { path: 'me', name:'MeInMain', component: Me },
                { path: 'password', name:'PasswordInMain', component: Password },
                { path: 'blog1', name:'Blog1InMain', component: Blog1 },
                { path: 'publish', name:'PublishInMain', component: Publish },
                { path: 'car1', name:'Car1InMain', component: Car1 },
            ],
            meta:{requiresAuth:true}
        },
        {path: '/back', name:'Back' , component : Back ,meta:{requireAuth:true},
            children:[
                {path: ''    , redirect:'/back/user'  },
                {path: 'data', name: 'DataInBack', component: Data ,meta:{name:'电车信息管理'}},
                {path: 'user', name: 'UserInBack', component: User ,meta:{name:'用户管理'}},
                {path: 'admin', name: 'AdminInBack', component: Admin ,meta:{name:'管理员管理'}},
                {path: 'category', name: 'CategoryInBack', component: Category ,meta:{name:'话题管理'}},
                {path: 'blog', name: 'BlogInBack', component: Blog ,meta:{name:'博客'}},
                {path: 'activity', name: 'ActivityInBack', component: Activity ,meta:{name:'活动'}},
                {path: 'comment', name: 'CommentInBack', component: Comment ,meta:{name:'评论管理'}},
            ]
        },
        { path: '/login', name: 'Login', component: Login ,meta:{requiresAuth:false}},
        { path: '/register', name: 'Register', component: Register ,meta:{requiresAuth:false}},
    ]
});

router.beforeEach((to,from,next)=>{
    if(to.meta.requiresAuth){
        const token = localStorage.getItem('token');
        if(token){
            const decodedToken = jwtDecode(token);
            console.log(decodedToken);
            const currentTime = Date.now() / 1000;
            if(decodedToken.exp > currentTime){
                next();
            }else{
                localStorage.removeItem('token');
                next({path:'/login',query:{redirect:to.fullPath}});
            }
        }else{
            next({path:'/login',query:{redirect:to.fullPath}});
        }
    }else{
        next();
    }
});

export default router;
