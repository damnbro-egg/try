package com.example.demo.service;

import com.example.demo.common.Result;
import com.example.demo.entity.Bloglikes;
import com.example.demo.mapper.BloglikesMapper;
import com.example.demo.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BloglikesService {
    private final BloglikesMapper likeMapper;
    private final BlogStatusService statusService;

    @Transactional
    public Result toggleLike(Integer blogId){
        Integer userId = JwtUtil.getCurrentUser().getId();
        if(likeMapper.exists(userId,blogId)){
            likeMapper.delete(userId,blogId);
            //statusService.decrementLikesCount(blogId);
            return Result.success("已取消点赞");
        }else{
            Bloglikes like = new Bloglikes();
            like.setBlogId(blogId);
            like.setUserId(userId);
            likeMapper.insert(like);
            //statusService.incrementLikesCount(blogId);
            return Result.success("点赞成功");
        }
    }

    @Transactional
    public boolean hasLiked(Integer blogId){
        System.out.println("------"+ likeMapper.exists(JwtUtil.getCurrentUser().getId(),blogId) +"-----------");
        return likeMapper.exists(JwtUtil.getCurrentUser().getId(),blogId);
    }

    @Transactional
    public Integer getLikeCount(Integer blogId){
        System.out.println("------"+ likeMapper.countByBlogId(blogId) +"-----------");
        return likeMapper.countByBlogId(blogId);
    }
}
