package com.example.demo.service;


import cn.hutool.db.PageResult;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.dto.params.BlogFavoritesDTO;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Blogfavorites;
import com.example.demo.mapper.BlogfavoritesMapper;
import com.example.demo.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BlogfavoritesService {
    private final BlogfavoritesMapper blogfavoritesMapper;
    private final BlogStatusService blogStatusService;

    @Transactional
    public Result togglefavorites(Integer blogId, String category){
        Integer userId = JwtUtil.getCurrentUser().getId();

        Blogfavorites existing = blogfavoritesMapper.selectByUserAndBlog(userId,blogId);
        if(existing != null){
            blogfavoritesMapper.delete(existing.getId());
            //blogStatusService.decrementFavoritesCount(blogId);
            return Result.success("已取消收藏");
        }else{
            Blogfavorites favorites = new Blogfavorites();
            favorites.setUserId(userId);
            favorites.setBlogId(blogId);
            favorites.setCategory(category);
            blogfavoritesMapper.insert(favorites);
            //blogStatusService.incrementFavoritesCount(blogId);
            return Result.success("收藏成功");
        }
    }

    public boolean isFavorited(Integer blogId) {
        Integer userId = JwtUtil.getCurrentUser().getId();
        System.out.println("------"+blogfavoritesMapper.exists(userId, blogId)+"-----------");
        return blogfavoritesMapper.exists(userId, blogId);
    }

    @Transactional
    public Integer getFavoriteCount(Integer blogId){
        System.out.println("------"+blogfavoritesMapper.countByBlogId(blogId)+"-----------");
        return blogfavoritesMapper.countByBlogId(blogId);
    }

    @Transactional(readOnly = true)
    public Page<Blog> getUserFavorites(Integer page, Integer size) {
        Integer userId = JwtUtil.getCurrentUser().getId();
        return blogfavoritesMapper.selectFavoritesBlogs(new Page<>(page, size), userId);
    }
}
