package com.example.demo.mapper;

import com.example.demo.entity.Bloglikes;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.mapstruct.Mapper;

@Mapper
public interface BloglikesMapper {
    @Insert("insert into bloglikes(user_id, blog_id) values (#{userId}, #{blogId})")
    int insert(Bloglikes like);

    @Delete("delete from bloglikes where user_id=#{userId} and blog_id=#{blogId}")
    int delete(@Param("userId") Integer userId, @Param("blogId") Integer blogId);

    @Select("select count(*) from bloglikes where user_id=#{userId} and blog_id = #{blogId}")
    boolean exists(@Param("userId") Integer userId, @Param("blogId") Integer blodId);

    @Select("select count(*) from bloglikes where blog_id = #{blogId}")
    int countByBlogId(@Param("blogId") Integer blogId);

}
