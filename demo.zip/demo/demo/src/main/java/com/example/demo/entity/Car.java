package com.example.demo.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

public class Car {
    @TableId(type = IdType.AUTO)
    private int id;
    private String carName;
    private String carModelNum;
    private String carType;
    private String carCharge;
    private String carPicture;
    private String carRange;
    private String carPrice;

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", carName='" + carName + '\'' +
                ", carModelNum='" + carModelNum + '\'' +
                ", carType='" + carType + '\'' +
                ", carCharge='" + carCharge + '\'' +
                ", carPicture='" + carPicture + '\'' +
                ", carRange='" + carRange + '\'' +
                ", carPrice='" + carPrice + '\'' +
                '}';
    }

    public String getCarPrice() {
        return carPrice;
    }

    public void setCarPrice(String carPrice) {
        this.carPrice = carPrice;
    }

    public String getCarRange() {
        return carRange;
    }

    public void setCarRange(String carRange) {
        this.carRange = carRange;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarModelNum() {
        return carModelNum;
    }

    public void setCarModelNum(String carModelNum) {
        this.carModelNum = carModelNum;
    }


    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getCarCharge() {
        return carCharge;
    }

    public void setCarCharge(String carCharge) {
        this.carCharge = carCharge;
    }

    public String getCarPicture() {
        return carPicture;
    }

    public void setCarPicture(String carPicture) {
        this.carPicture = carPicture;
    }

}
