package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Account;
import com.example.demo.entity.Blog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface BlogMapper {
    void insert( Blog blog);

    Blog selectByTitle(String title);

    void deleteById(Integer id);

    void updateById(Blog blog);

    Blog selectById(Integer id);

    List<Blog> selectAll(@Param("blog")Blog blog);

    List<Blog> selectHot(@Param("blog")Blog blog, @Param("num")Integer num);

    IPage<Blog> selectPage(Page<Blog> page, @Param("blog")Blog blog);

    IPage<Blog> selectPage1(Page<Blog> page, @Param("blog")Blog blog);

    IPage<Blog> selectPage2(Page<Blog> page, @Param("blog")Blog blog, @Param("account")Account account);
}
