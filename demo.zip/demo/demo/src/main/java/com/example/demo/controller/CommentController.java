package com.example.demo.controller;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.common.Result;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Comment;
import com.example.demo.service.CommentService;
import com.example.demo.vo.params.CommentParam;
import com.example.demo.vo.params.CommentVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("comment")
public class CommentController {
    @Autowired
    private CommentService commentService;

    @GetMapping("article/{id}")
    public Result commentByArticleId(@PathVariable("id") Integer id){
        List<CommentVo> cv = commentService.commentByArticleId(id);
        System.out.println(cv);
        return Result.success(cv);
    }

    @PostMapping("create/change")
    public Result comment(@RequestBody CommentParam commentParam){
        commentService.comment(commentParam);
        return Result.success();
    }

    @PostMapping("/add")
    public Result add(@RequestBody Comment comment) {
        commentService.add(comment);
        return Result.success();
    }

    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Integer id){
        commentService.deleteById(id);
        return Result.success();
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<Integer> ids){
        commentService.deleteBatch(ids);
        return Result.success();
    }

    @PutMapping("/update")
    public Result updateById(@RequestBody Comment comment){
        commentService.updateById(comment);
        return Result.success();
    }

    @GetMapping("/selectByAuthorId/{id}")
    public Result selectByAuthorId(@PathVariable Integer id){
        List<Comment> list = commentService.selectByAuthorId(id);
        return Result.success(list);
    }

    @GetMapping("/selectByName/{name}")
    public Result selectByName(@PathVariable String name){
        List<Comment> list = commentService.selectByName(name);
        return Result.success(list);
    }

    @GetMapping("/selectAll")
    public Result selectAll(Comment comment){
        List<Comment> list = commentService.selectAll(comment);
        return Result.success(list);
    }

    @GetMapping("/selectPage")
    public Result selectPage(
        Comment comment,
        @RequestParam(value="page", defaultValue = "1") Integer pageNum,
        @RequestParam(value="size", defaultValue = "12") Integer pageSize){
        IPage<Comment> page = commentService.selectPage(comment, pageNum, pageSize);
        return Result.success(page);
    }
}
