package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.entity.Bloglikes;
import com.example.demo.service.BloglikesService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.batch.BatchTransactionManager;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bloglikes")
@RequiredArgsConstructor
public class BloglikesController {
    private final BloglikesService bloglikesService;

    @PostMapping("/toggle")
    public Result toggleLike(@RequestParam Integer blogId) {
        return bloglikesService.toggleLike(blogId);
    }

    @GetMapping("/status")
    public Result checkLikeStatus(@RequestParam Integer blogId){
        System.out.println("checkstatus------------------------");
        return Result.success(bloglikesService.hasLiked(blogId));
    }

    @GetMapping("/count")
    public Result getLikeCount(@RequestParam Integer blogId){
        System.out.println("getLikeCount-----------------------");
        return Result.success(bloglikesService.getLikeCount(blogId));
    }
}
