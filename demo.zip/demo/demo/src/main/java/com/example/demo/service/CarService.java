package com.example.demo.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Car;
import com.example.demo.entity.User;
import com.example.demo.mapper.CarMapper;

import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {
    @Resource
    private CarMapper carMapper;

    public Car selectById(Integer id) {
        return carMapper.selectById(id);
    }

    public List<Car> selectAll(Car car) {
        return carMapper.selectAll(car);
    }

    public IPage<Car> selectPage(Car car, Integer pageNum, Integer pageSize) {
        /*QueryWrapper<Car> queryWrapper = new QueryWrapper<>(car);*/
        Page<Car> page = new Page<>(pageNum, pageSize);
        return carMapper.selectPage(page, car);
    }

}
