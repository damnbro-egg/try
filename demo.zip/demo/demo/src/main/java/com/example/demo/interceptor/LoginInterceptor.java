package com.example.demo.interceptor;

import com.auth0.jwt.exceptions.TokenExpiredException;
import com.example.demo.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.security.SignatureException;
import java.util.Enumeration;
import java.util.Map;

@Component
public class LoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7); // 去掉 "Bearer " 前缀
            try {
                System.out.println(request.getHeader("Authorization")+""+request.getHeader("Content-Type"));
                System.out.println("开始解析token！\n" + token);
                Map<String, Object> claims = JwtUtil.parseToken(token);
                System.out.println("解析succees！");
                return true;
            } catch (TokenExpiredException e) {
                System.out.println("Token 已过期: " + token);
                response.setStatus(401);
                response.getWriter().write("Token expired");
                return false;
            } catch (Exception e) {
                System.out.println("失败了token" + token);
                response.setStatus(401);
                response.getWriter().write("Invalid token");
                return false;
            }
        }
        // 如果没有有效的 Authorization 头，返回 401
        response.setStatus(401);
        response.getWriter().write("Missing Authorization header");
        return false;
    }

}
