package com.example.demo.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.common.enums.Constants;
import com.example.demo.common.enums.ResultCodeEnum;
import com.example.demo.common.enums.RoleEnum;

import com.example.demo.entity.Account;
import com.example.demo.entity.User;
import com.example.demo.exception.CustomException;
import com.example.demo.mapper.UserMapper;
import com.example.demo.utils.JwtUtil;
import com.example.demo.utils.TokenUtils;
import com.example.demo.vo.params.UserVo;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Validated
public class UserService {
    @Resource
    private UserMapper userMapper;

    public Map<String, Object> login(Account account) {
            String username = account.getUsername();
            User dbUser = userMapper.selectByUsername(username);
            if (dbUser == null) {
                throw new CustomException("500", "账号不存在");
            }
            String password = account.getPassword();
            if (!dbUser.getPassword().equals(password)) {
                throw new CustomException("500", "账号或密码错误");
            }
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", dbUser.getId());
            claims.put("username", dbUser.getUsername());
            claims.put("role",dbUser.getRole());
            String token = JwtUtil.genToken(claims);
            Map<String, Object> data = new HashMap<>();
            data.put("token", token);
            data.put("user", dbUser);
            return data;
    }

    /*
            TokenUtils.createToken(dbUser.getId() + "-" +"USER", dbUser.getPassword());
            account.setToken();
            return dbUser;
            String token = TokenUtils.createToken(dbAdmin.getId() + "-" + "ADMIN", dbAdmin.getPassword);
            account.setToken(token);
            return dabAdmin;
         */

    public void add(User user) {
        //1,account
         User dbUser = userMapper.selectByUsername(user.getUsername());
        if(dbUser != null){
            throw new CustomException(ResultCodeEnum.USER_EXIST_ERROR);
        }
        //2.mima
        if(ObjectUtils.isEmpty(user.getPassword())){
            user.setPassword(Constants.USER_DEFAULT_PASSWORD.getValue());
        }
        //3.name
        if(ObjectUtils.isEmpty(user.getName())){
            user.setName(user.getUsername());
        }
        //4.role
        user.setRole(RoleEnum.USER.name());
        userMapper.insert(user);
    }

    public void deleteById(Integer id) {
        userMapper.deleteById(id);
    }

    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    public void updateById(User user) {
        userMapper.updateById(user);
    }

    public UserVo selectUserVoById(Integer id) {
        User user = userMapper.selectById(id);
        UserVo userVo = new UserVo();
        if (user != null) {
            // 只有当 user 不为 null 时才进行属性复制
            BeanUtils.copyProperties(user, userVo);
            System.out.println(user);

        }
        return userVo;
    };

    public User selectById(Integer id) {
        return userMapper.selectById(id);
    }

    public List<User> selectAll(User user) {
        return userMapper.selectAll(user);
    }

    public IPage<User> selectPage(User user, Integer pageNum, Integer pageSize) {
        /*QueryWrapper<User> queryWrapper = new QueryWrapper<User>();*/
        Page<User> page = new Page(pageNum,pageSize);
        return userMapper.selectPage(page, user);
    }

    public void register(@Valid User user) {
        //1,account
        User dbUser = userMapper.selectByUsername(user.getUsername());
        if(dbUser != null){
            throw new CustomException(ResultCodeEnum.USER_EXIST_ERROR);
        }
        //2.mima
        if(ObjectUtils.isEmpty(user.getPassword())){
            user.setPassword(Constants.USER_DEFAULT_PASSWORD.getValue());
        }
        //3.name
        if(ObjectUtils.isEmpty(user.getName())){
            user.setName(user.getUsername());
        }
        //4.role
        user.setRole(RoleEnum.USER.name());

        userMapper.insert(user);
    }

    public void updatePassword(Account account) {
        if(!account.getNewpassword1().equals(account.getNewpassword2())){
            throw new CustomException("50001","您两次输入的密码不一致");
        }
        User dbUser = userMapper.selectByUsername(account.getUsername());
        if(!account.getPassword().equals(dbUser.getPassword())){
            throw new CustomException("50002","输入的原密码不正确");
        }
        dbUser.setPassword(account.getNewpassword1());
        userMapper.updateById(dbUser);
        /*
        Account currentUser = TokenUtils.getCurrentUser();
        if(account.getPassword().equals(currentUser.getPassword())){
            throw new CustomException("50002","原密码输入错误");
        }
        User user = userMapper.selectById(currentUser.getId().toString());
        user.setPassword(user.getPassword());
        userMapper.updateById(user);
        */
    }
}
