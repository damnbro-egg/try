package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Account;
import com.example.demo.entity.Car1;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface Car1Mapper {
    void insert(Car1 car1);

    Car1 selectByTitle(String title);

    void deleteById(Integer id);

    void updateById(Car1 car1);

    Car1 selectById(Integer id);

    List<Car1> selectAll(@Param("car1") Car1 car1);

    List<Car1> selectHot(@Param("car1") Car1 car1, @Param("num") Integer num);

    IPage<Car1> selectPage(Page<Car1> page, @Param("car1") Car1 car1);

    IPage<Car1> selectPage1(Page<Car1> page, @Param("car1") Car1 car1);

    IPage<Car1> selectPage2(Page<Car1> page, @Param("car1") Car1 car1, @Param("account") Account account);
}