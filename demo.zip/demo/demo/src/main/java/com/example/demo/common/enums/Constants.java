package com.example.demo.common.enums;

public enum Constants {
    USER_DEFAULT_PASSWORD("123");
    private Constants(String value) {
        this.value = value;
    }
    private final String value;

    public String getValue() {
        return value;
    }
}
