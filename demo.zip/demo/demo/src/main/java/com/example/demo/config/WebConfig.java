package com.example.demo.config;

import com.example.demo.interceptor.AdminInterceptor;
import com.example.demo.interceptor.JWTInterceptor;
import com.example.demo.interceptor.LoginInterceptor;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private AdminInterceptor adminInterceptor;

    @Autowired
    private LoginInterceptor loginInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        System.out.println("----开始1----");
        registry.addInterceptor(loginInterceptor)
                .addPathPatterns("/**")
                .addPathPatterns("/comment/create/change")
                .excludePathPatterns("/login","/register","/files/**");
        System.out.println("----权限验证----");
        registry.addInterceptor(adminInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/login","/register","/files/**");
    }
/*
    @Autowired
    private JWTInterceptor jwtInterceptor;

    @Bean
    public JWTInterceptor jwtInterceptor(){
        return new JWTInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry){
        System.out.println("----开始2----");
        registry.addInterceptor(jwtInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/login","/register","/files/**","/role/selectAll");
    }
*/
}
