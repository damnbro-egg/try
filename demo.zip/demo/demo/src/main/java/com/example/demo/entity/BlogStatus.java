package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("blog_status")
public class BlogStatus {
    @TableId(value="blog_id", type= IdType.INPUT)
    private Integer blogId;

    private Integer likeCount=0;
    private Integer favoriteCount=0;
    private Integer readCount=0;
    private LocalDateTime updateTime;
}
