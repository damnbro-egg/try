package com.example.demo.interceptor;

import com.example.demo.annotation.RequireAdmin;
import com.example.demo.entity.Account;
import com.example.demo.entity.User;
import com.example.demo.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AdminInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception
    {
        if(!(handler instanceof HandlerMethod)){
            return true;
        }
        HandlerMethod hm = (HandlerMethod) handler;
        RequireAdmin requireAdmin = hm.getMethodAnnotation(RequireAdmin.class);

        if(requireAdmin == null){
            return true;
        }

        Account account = JwtUtil.getCurrentUser();
        if(!"ADMIN".equals(account.getRole())){
            throw new RuntimeException("权限不足");
        }
        return true;
    }
}
