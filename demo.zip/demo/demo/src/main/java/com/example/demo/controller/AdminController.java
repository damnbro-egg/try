package com.example.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.common.Result;
import com.example.demo.entity.Admin;
import com.example.demo.service.AdminService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Resource
    private AdminService adminService;

    @PostMapping("/add")
    public Result add(@RequestBody Admin admin) {
        adminService.add(admin);
        return Result.success();
    }

    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Integer id){
        adminService.deleteById(id);
        return Result.success();
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<Integer> ids){
        adminService.deleteBatch(ids);
        return Result.success();
    }

    @PutMapping("/update")
    public Result updateById(@RequestBody Admin admin){
        adminService.updateById(admin);
        return Result.success();
    }

    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id){
        Admin admin = adminService.selectById(id);
        return Result.success(admin);
    }

    @GetMapping("/selectAll")
    public Result selectAll(Admin admin){
        List<Admin> list = adminService.selectAll(admin);
        return Result.success(list);
    }

    @GetMapping("/selectPage")
    public Result selectPage(
            Admin admin,
            @RequestParam(value="page", defaultValue = "1") Integer pageNum,
            @RequestParam(value="size", defaultValue = "12") Integer pageSize){
        for(int i=1; i<10; i++){
            System.out.println(admin.getUsername()+"\n");
        }
        IPage<Admin> page = adminService.selectPage(admin, pageNum, pageSize);
        return Result.success(page);
    }

}














/*@GetMapping("/admin/findAdminArtical)
            public List<A>
    @PostMapping("/add")
    public String add(Admin admin) {
        int i= adminMapper.insert(admin);
        if(i>0) {
            return "insert-admin-success";
        }else{
            return "insert-admin-fail";
        }
    }

        @Autowired
    private AdminMapper adminMapper;

    @GetMapping("/findAll")
    public List<Admin> findAll() {
        List<Admin> list = adminMapper.select();
        System.out.println(list);
        return list;
    }
    */