package com.example.demo.service;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Activity;
import com.example.demo.mapper.ActivityMapper;
import com.example.demo.utils.JwtUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Service
@Validated
public class ActivityService {
    @Resource
    private ActivityMapper activityMapper;

    public void add(Activity activity) {
        activityMapper.insert(activity);
    }

    public void deleteById(Integer id) {
        activityMapper.deleteById(id);
    }

    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    public void updateById(Activity activity) {
        activityMapper.updateById(activity);
    }

    public Activity selectById(Integer id) {
        return activityMapper.selectById(id);
    }

    public List<Activity> selectAll(Activity activity) {
        return activityMapper.selectAll(activity);
    }

    public IPage<Activity> selectPage(Activity activity, Integer pageNum, Integer pageSize) {
        Page<Activity> page = new Page(pageNum,pageSize);
        return activityMapper.selectPage(page, activity);
    }
}