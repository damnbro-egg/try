package com.example.demo.vo;

public class BlogApp {
}
