package com.example.demo.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.thread.ThreadUtil;
import com.example.demo.common.Result;
import com.example.demo.exception.CustomException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/files")
public class FileController {

    @GetMapping("/download/{filename}")
    public void download(@PathVariable String filename, HttpServletResponse response) throws Exception {
        String filePath = System.getProperty("user.dir") + "/files/";
        String realPath = filePath + filename;
        boolean exist = FileUtil.exist(realPath);
        if (!exist) {
            throw new CustomException("5501", "文件不存在");
        }

        // 设置响应头
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(filename, StandardCharsets.UTF_8));

        try (ServletOutputStream out = response.getOutputStream()) {
            byte[] bytes = FileUtil.readBytes(realPath);
            out.write(bytes);
            out.flush();
        }
    }

    @PostMapping("/upload")
    public Result upload(@RequestParam("file") MultipartFile file) {
        try {
            String filePath = System.getProperty("user.dir") + "/files/";
            if (!FileUtil.isDirectory(filePath)) {
                FileUtil.mkdir(filePath);
            }
            byte[] bytes = file.getBytes();
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            String encodeFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);
            FileUtil.writeBytes(bytes, filePath + encodeFileName);
            String url = "http://localhost:8088/files/download/" + encodeFileName;
            //String url = "http://47.76.140.101:8088/files/download/" + encodeFileName;
            return Result.success(url);
        } catch (Exception e) {
            // 可以根据具体情况进行更详细的异常处理
            return Result.error("上传文件失败: " + e.getMessage());
        }
    }

    @PostMapping("/editor/upload")
    public Dict editorUpload(MultipartFile file){
        String flag;
        synchronized (FileController.class) {
            flag = System.currentTimeMillis() + "";
            ThreadUtil.sleep(1L);
        }
        String fileName= file.getOriginalFilename();
        String filePath = System.getProperty("user.dir") + "/files/";
        try{
            if(!FileUtil.isDirectory(filePath)){
                FileUtil.mkdir(filePath);
            }
            FileUtil.writeBytes(file.getBytes(),filePath + flag +"-" + fileName);
            System.out.println(fileName+"上传成功");

        }catch(Exception e){
            System.out.println(e);
        }
        /*String http = "http:.." + ip + ":" + port +"/files";*/
        String http = "http://" + "localhost" + ":" + "8088" +"/files/download/";
        //String http = "http://" + "47.76.140.101" + ":" + "8088" +"/files/download/";
        return Dict.create().set("errno", 0 ).set("data", CollUtil.newArrayList(Dict.create().set("url", http + flag + "-" +fileName)));
    }

}
