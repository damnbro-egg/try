package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Category;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
@Mapper
public interface CategoryMapper {
    void insert( Category category);

    Category selectByName(String name);

    void deleteById(Integer id);

    void updateById(Category category);

    Category selectById(Integer id);

    List<Category> selectAll(Category category);

    IPage<Category> selectPage(Page<Category> page, Category category);
}
