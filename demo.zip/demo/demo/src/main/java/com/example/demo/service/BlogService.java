package com.example.demo.service;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Blog;
import com.example.demo.mapper.BlogMapper;
import com.example.demo.utils.JwtUtil;
import io.swagger.models.auth.In;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Service
@Validated
public class BlogService {
    @Resource
    private BlogMapper blogMapper;

    @Transactional(rollbackFor = Exception.class)
    public void add(Blog blog) {
        blog.setDate(DateUtil.today());
        Account currentUser = JwtUtil.getCurrentUser();
        if(RoleEnum.USER.name().equals(currentUser.getRole())){
            blog.setUserId(currentUser.getId());
        }
        blogMapper.insert(blog);
    }

    public void deleteById(Integer id) {
        blogMapper.deleteById(id);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    public void updateStatus(Blog blog){blogMapper.updateById(blog);}

    public void updateById(Blog blog) {
        blogMapper.updateById(blog);
    }

    public Blog selectById(Integer id) {
        return blogMapper.selectById(id);
    }

    public List<Blog> selectHot(Blog blog, Integer num) {return blogMapper.selectHot(blog, num);}

    public List<Blog> selectAll(Blog blog) {
        return blogMapper.selectAll(blog);
    }

    @Transactional(rollbackFor = Exception.class)
    public IPage<Blog> selectPage2(Blog blog, Integer pageNum, Integer pageSize) {
        Page<Blog> page = new Page(pageNum,pageSize);
        Account account = JwtUtil.getCurrentUser();
        return blogMapper.selectPage2(page, blog, account);
    }

    @Transactional(rollbackFor = Exception.class)
    public IPage<Blog> selectPage(Blog blog, Integer pageNum, Integer pageSize) {
        Page<Blog> page = new Page(pageNum,pageSize);
        Account account = JwtUtil.getCurrentUser();
        if("ADMIN".equals(account.getRole())){
            return blogMapper.selectPage1(page, blog);
        }else{
            return blogMapper.selectPage(page,blog);
        }
    }
}