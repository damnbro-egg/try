package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.common.Result;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Comment;
import com.example.demo.vo.params.CommentParam;
import com.example.demo.vo.params.CommentVo;
import org.springframework.stereotype.Service;

import java.util.List;

public interface CommentService {

    List<CommentVo> commentByArticleId(Integer id);

    void comment(CommentParam commentParam);

    void add(Comment comment);

    void deleteById(Integer id);

    void deleteBatch(List<Integer> ids);

    void updateById(Comment comment);

    List<Comment> selectByAuthorId(Integer authorId);

    List<Comment> selectByName(String name);

    List<Comment> selectAll(Comment comment);

    IPage<Comment> selectPage(Comment comment, Integer pageNum, Integer pageSize);
}
