package com.example.demo.entity;

public class Comment {
    private Integer id;
    private String content;
    private Long createDate;
    private Integer articleId;
    private Integer authorId;
    private Integer parentId;
    private Integer toUid;
    private Integer level;

    public void setCreateDate(Long createDate) {
        this.createDate = createDate;
    }

    public Long getCreateDate() {
        return createDate;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", createDate=" + createDate +
                ", articleId=" + articleId +
                ", authorId=" + authorId +
                ", parentId=" + parentId +
                ", toUid=" + toUid +
                ", level=" + level +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getToUid() {
        return toUid;
    }

    public void setToUid(Integer toUid) {
        this.toUid = toUid;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }
}
