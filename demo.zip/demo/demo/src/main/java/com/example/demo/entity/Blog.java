package com.example.demo.entity;

public class Blog {
    private Integer id;
    private String title;
    private String content;
    private String descr;
    private String cover;
    private String tags;
    private Integer userId;
    private String date;
    private Integer readCount;
    private Integer categoryId;
    private String categoryName;
    private String userName;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Blog{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", descr='" + descr + '\'' +
                ", cover='" + cover + '\'' +
                ", tags='" + tags + '\'' +
                ", userId=" + userId +
                ", date='" + date + '\'' +
                ", readCount=" + readCount +
                ", categoryId=" + categoryId +
                ", categoryName='" + categoryName + '\'' +
                ", userName='" + userName + '\'' +
                ", status=" + status +
                '}';
    }

    private Integer status;


    public String getCategoryName() {
        return categoryName;
    }

    public String getUserName() {
        return userName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
