package com.example.demo.common.enums;

public enum ResultCodeEnum {
    SUCCESS("200", "成功"),
    PARAM_ERROR("400", "参数异常"),
    TOKEN_INVALID_ERROR("401", "无效的token"),
    TOKEN_CHECK_ERROR("401", "token验证失败，请重新登录"),
    PARAM_LOSE_ERROR("400", "参数缺失"),
    SYSTEM_ERROR("500", "系统异常"),
    USER_EXIST_ERROR("5081", "用户名已存在"),
    USER_NOT_LOGIN("5082", "用户未登录"),
    USER_LOGIN_ERROR("5083", "账号或密码错误"),
    USER_NOT_EXIST_ERROR("5004", "用户不存在"),
    PARAM_PASSWORD_ERROR("5005", "原密码输入错误");

    public String code;
    public String msg;

    ResultCodeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}

