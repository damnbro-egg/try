package com.example.demo.service;

import com.example.demo.mapper.BlogStatusMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BlogStatusService {
    private final BlogStatusMapper blogStatusMapper;

    @Transactional
    public void incrementLikesCount(Integer blogId){
        blogStatusMapper.incrementLikeCount(blogId);
    }

    @Transactional
    public void incrementFavoritesCount(Integer blogId){
        blogStatusMapper.incrementLikeCount(blogId);
    }

    @Transactional
    public void decrementLikesCount(Integer blogId){
        blogStatusMapper.decrementFavoriteCount(blogId);
    }

    @Transactional
    public void decrementFavoritesCount(Integer blogId){
        blogStatusMapper.decrementFavoriteCount(blogId);
    }


}
