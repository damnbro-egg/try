package com.example.demo.controller;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.annotation.RequireAdmin;
import com.example.demo.common.Result;
import com.example.demo.entity.Category;
import com.example.demo.entity.Blog;
import com.example.demo.entity.User;
import com.example.demo.service.CategoryService;
import com.example.demo.service.BlogService;
import com.example.demo.utils.JwtUtil;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/blog")
public class BlogController {

    @Resource
    private BlogService blogService;

    @PostMapping("/add")
    public Result add(@RequestBody Blog blog) {
        blog.setDate(DateUtil.today());
        blogService.add(blog);
        return Result.success();
    }

    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Integer id){
        blogService.deleteById(id);
        return Result.success();
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<Integer> ids){
        blogService.deleteBatch(ids);
        return Result.success();
    }

    @PutMapping("/update")
    public Result updateById(@RequestBody Blog blog){
        blogService.updateById(blog);
        return Result.success();
    }

    @RequireAdmin
    @PutMapping("/updateStatus")
    public Result updateStatus(@RequestBody Blog blog){
        blogService.updateStatus(blog);
        return Result.success();
    }

    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id){
        Blog blog = blogService.selectById(id);
        return Result.success(blog);
    }

    @GetMapping("/selectHot")
    public Result selectHot(Blog blog,Integer num){
        List<Blog> list = blogService.selectHot(blog, num);
        return Result.success(list);
    }

    @GetMapping("/selectAll")
    public Result selectAll(Blog blog){
        List<Blog> list = blogService.selectAll(blog);
        return Result.success(list);
    }

    @GetMapping("/selectPage2")
    public Result selectPage2(
            Blog blog,
            @RequestParam(value="page", defaultValue = "1") Integer pageNum,
            @RequestParam(value="size", defaultValue = "12") Integer pageSize){
        for(int i=1; i<10; i++){
            System.out.println(blog.getTitle()+"\n");
        }
        IPage<Blog> page = blogService.selectPage2(blog, pageNum, pageSize);
        return Result.success(page);
    }

    @GetMapping("/selectPage")
    public Result selectPage(
            Blog blog,
            @RequestParam(value="page", defaultValue = "1") Integer pageNum,
            @RequestParam(value="size", defaultValue = "12") Integer pageSize){
        for(int i=1; i<10; i++){
            System.out.println(blog.getTitle()+"\n");
        }
        IPage<Blog> page = blogService.selectPage(blog, pageNum, pageSize);
        return Result.success(page);
    }
}