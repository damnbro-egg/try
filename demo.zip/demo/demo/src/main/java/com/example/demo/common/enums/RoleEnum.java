package com.example.demo.common.enums;

public enum RoleEnum {
    ADMIN,
    USER
}
