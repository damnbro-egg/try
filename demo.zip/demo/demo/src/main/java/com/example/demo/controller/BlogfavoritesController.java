package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.service.BlogfavoritesService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/blogfavorites")
@RequiredArgsConstructor
public class BlogfavoritesController {
    private final BlogfavoritesService blogfavoritesService;

    @PostMapping("/toggle")
    public Result togglefavorites(
            @RequestParam Integer blogId,
            @RequestParam(required = false) String category) {
        return blogfavoritesService.togglefavorites(blogId,category);
    }

    @GetMapping("/status")
    public Result checkFavoriteStatus(@RequestParam Integer blogId) {
        return Result.success(blogfavoritesService.isFavorited(blogId));
    }

    @GetMapping("/count")
    public Result getLikeCount(@RequestParam Integer blogId){
        return Result.success(blogfavoritesService.getFavoriteCount(blogId));
    }

    @GetMapping("/list")
    public Result getUserFavorites(
            @RequestParam(defaultValue="1")Integer page,
            @RequestParam(defaultValue="10")Integer size) {
        return Result.success(blogfavoritesService.getUserFavorites(page,size));
    }


}
