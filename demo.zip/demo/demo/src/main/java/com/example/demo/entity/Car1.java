package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@TableName("car1")
@Data
public class Car1 {
    // 基本信息
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String name;
    private String brand;
    private String model;
    private String carType;
    private String powerType;
    private BigDecimal price;
    private String carPicture;

    // 动力系统
    private String motorType;
    private String motorPower;
    private String torque;
    private String acceleration;
    private String topSpeed;

    // 电池信息
    private String batteryType;
    private String batteryCapacity;
    private String range;
    private String chargeTime;
    private String slowChargeTime;

    // 车身尺寸
    private String length;
    private String width;
    private String height;
    private String wheelbase;
    private String weight;

    // 配置信息
    private String seatNum;
    private String driveType;
    private String releaseDate;
    private String warranty;

    // 其他信息
    private String description;
    private Integer status;

}
