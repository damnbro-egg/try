package com.example.demo.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.mapstruct.Mapper;

@Mapper
public interface BlogStatusMapper {
    @Update("update blog_status set like_count = like_count+1 where blog_id=#{blogId}")
    int incrementLikeCount(@Param("blogId") Integer blogId);

    @Update("update blog_status set favotite_count = favorite_count+1 where blog_id=#{blogId}")
    int incrementFavoriteCount(@Param("blogId") Integer blogId);

    @Update("update blog_status set like_count = like_count-1 where blog_id=#{blogId}")
    int decrementLikeCount(@Param("blogId") Integer blogId);

    @Update("update blog_status set favotite_count = favorite_count-1 where blog_id=#{blogId}")
    int decrementFavoriteCount(@Param("blogId") Integer blogId);
}
