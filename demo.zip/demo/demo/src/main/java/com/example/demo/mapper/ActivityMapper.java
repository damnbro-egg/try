package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Activity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface ActivityMapper {
    void insert( Activity activity);

    Activity selectByName(String name);

    void deleteById(Integer id);

    void updateById(Activity activity);

    Activity selectById(Integer id);

    List<Activity> selectAll(Activity activity);

    IPage<Activity> selectPage(Page<Activity> page,@Param("activity") Activity activity);
}