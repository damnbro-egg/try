package com.example.demo.dto.params;

import lombok.Data;

@Data
public class BlogItemDTO {
    private Integer id;
    private String title;
    private String descr;
    private String cover;
    private Integer readCount;
}
