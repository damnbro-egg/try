package com.example.demo.service;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Car1;
import com.example.demo.mapper.Car1Mapper;
import com.example.demo.utils.JwtUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Service
@Validated
public class Car1Service {
    @Resource
    private Car1Mapper car1Mapper;

    @Transactional(rollbackFor = Exception.class)
    public void add(Car1 car1) {
        Account currentUser = JwtUtil.getCurrentUser();
        if (RoleEnum.USER.name().equals(currentUser.getRole())) {
            // 如果需要关联用户，可以设置userId
            // car1.setUserId(currentUser.getId());
        }
        car1Mapper.insert(car1);
    }

    public void deleteById(Integer id) {
        car1Mapper.deleteById(id);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            this.deleteById(id);
        }
    }

    public void updateStatus(Car1 car1) {
        car1Mapper.updateById(car1);
    }

    public void updateById(Car1 car1) {
        car1Mapper.updateById(car1);
    }

    public Car1 selectById(Integer id) {
        return car1Mapper.selectById(id);
    }

    public List<Car1> selectHot(Car1 car1, Integer num) {
        return car1Mapper.selectHot(car1, num);
    }

    public List<Car1> selectAll(Car1 car1) {
        return car1Mapper.selectAll(car1);
    }

    @Transactional(rollbackFor = Exception.class)
    public IPage<Car1> selectPage2(Car1 car1, Integer pageNum, Integer pageSize) {
        Page<Car1> page = new Page<>(pageNum, pageSize);
        Account account = JwtUtil.getCurrentUser();
        return car1Mapper.selectPage2(page, car1, account);
    }

    @Transactional(rollbackFor = Exception.class)
    public IPage<Car1> selectPage(Car1 car1, Integer pageNum, Integer pageSize) {
        Page<Car1> page = new Page<>(pageNum, pageSize);
        Account account = JwtUtil.getCurrentUser();
        if ("ADMIN".equals(account.getRole())) {
            return car1Mapper.selectPage1(page, car1);
        } else {
            return car1Mapper.selectPage(page, car1);
        }
    }
}