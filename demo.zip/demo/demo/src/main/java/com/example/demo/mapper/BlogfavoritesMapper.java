package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.dto.params.BlogFavoritesDTO;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Blogfavorites;
import org.apache.ibatis.annotations.*;
import org.mapstruct.Mapper;

import javax.imageio.IIOParam;

@Mapper
public interface BlogfavoritesMapper extends BaseMapper<Blogfavorites> {
    @Insert("INSERT INTO blogfavorites(user_id, blog_id, category)"+
            "VALUES (#{userId}, #{blogId}, #{category})")
    @Options(keyProperty="id")
    int insert(Blogfavorites favorites);

    @Delete("delete from blogfavorites where id = #{id}")
    int delete(Integer id);

    @Select("select * from blogfavorites where user_id = #{userId} and blog_id=#{blogId}")
    Blogfavorites selectByUserAndBlog(
            @Param("userId") Integer userId,
            @Param("blogId") Integer blogId);

    @Select("select count(*) from blogfavorites where user_id=#{userId} AND blog_id=#{blogId}")
    boolean exists(@Param("userId")Integer userId, @Param("blogId")Integer blogId);

    @Select("select count(*) from blogfavorites where blog_id = #{blogId}")
    int countByBlogId(@Param("blogId") Integer blogId);

    /*    @Select("select * from blogfavorites where user_id=#{userId} order by created_at desc")
    IPage<Blogfavorites> selectPageByUser(
            Page<Blogfavorites> page,
            @Param("userId") Integer userId);*/
    // BlogfavoritesMapper.java
    @Select("SELECT b.* FROM blogfavorites f " +
            "JOIN blog b ON f.blog_id = b.id " +
            "WHERE f.user_id = #{userId} " +
            "ORDER BY f.created_at DESC")
    Page<Blog> selectFavoritesBlogs(Page<Blog> page, @Param("userId") Integer userId);
}
