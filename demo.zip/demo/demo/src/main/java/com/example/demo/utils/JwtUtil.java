package com.example.demo.utils;

import cn.hutool.core.util.StrUtil;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.example.demo.entity.Account;
import com.example.demo.service.AdminService;
import com.example.demo.service.UserService;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Date;
import java.util.Map;

@Component
public class JwtUtil {
    private static final String KEY = "demo";
    private static final String BEARER_PREFIX = "Bearer ";

    @Resource
    AdminService adminService;
    @Resource
    UserService userService;
    static AdminService staticAdminService;
    static UserService staticUserService;

    @PostConstruct
    public void init() {
        staticAdminService = adminService;
        staticUserService = userService;
    }


    public static String genToken(Map<String, Object> claims) {
        return JWT.create()
                .withClaim("claims", claims)
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 6))
                .sign(Algorithm.HMAC256(KEY));
    }

    public static Map<String, Object> parseToken(String token) {
        // 去除 Bearer 前缀
        if (token != null && token.startsWith(BEARER_PREFIX)) {
            token = token.substring(BEARER_PREFIX.length());
        }
        try {
            return JWT.require(Algorithm.HMAC256(KEY))
                    .build()
                    .verify(token)
                    .getClaim("claims")
                    .asMap();
        } catch (JWTVerificationException e) {
            // 打印详细的异常信息，方便调试
            System.err.println("Token 验证失败: " + e.getMessage());
            throw e;
        }
    }

    public static Account getCurrentUser() {
        Account account = null;
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            String authHeader = request.getHeader("Authorization");
            String token = null;
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                token = authHeader.substring(7);
            }
            if (StrUtil.isBlank(token)) {
                String paramToken = request.getParameter("token");
                if (paramToken != null && paramToken.startsWith(BEARER_PREFIX)) {
                    token = paramToken.substring(BEARER_PREFIX.length());
                }
            }
            if (StrUtil.isBlank(token)) {
                return null;
            }
            Map<String, Object> claims = parseToken(token);

            Integer id = (Integer) claims.get("id");
            String role = (String) claims.get("role");

            if ("ADMIN".equals(role)) {
                account = staticAdminService.selectById(id);
            } else if ("USER".equals(role)) {
                account = staticUserService.selectById(id);
            }
            return account;
        } catch (JWTVerificationException e) {
            System.err.println("Token 验证失败: " + e.getMessage());
        } catch (NumberFormatException | NullPointerException e) {
            System.err.println("解析 Token 信息时出错: " + e.getMessage());
        }
        return account;
    }
}
