package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface AdminMapper {
    void insert( Admin admin);

    Admin selectByUsername(String username);

    void deleteById(Integer id);

    void updateById(Admin admin);

    Admin selectById(Integer id);

    List<Admin> selectAll(Admin admin);

    IPage<Admin> selectPage(Page<Admin> page, Admin admin);
}



















  /* @Select("select * from admin")
    public List<Admin> select();

    @Insert("insert into admin values(#{id},#{adminname},#{password})")
    public int insert(Admin admin);
    */