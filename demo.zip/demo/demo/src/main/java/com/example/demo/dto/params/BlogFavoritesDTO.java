package com.example.demo.dto.params;

import com.example.demo.entity.Blog;
import lombok.Data;

import java.time.LocalDateTime;
@Data
public class BlogFavoritesDTO {
    private Integer favoriteId;
    private LocalDateTime favoriteTime;
    private String category;
    private Blog blog;
}
