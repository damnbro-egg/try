package com.example.demo.vo.params;

import lombok.Data;

@Data
public class UserVo {
    private String name;
    private String avatar;
    private Integer id;
}
