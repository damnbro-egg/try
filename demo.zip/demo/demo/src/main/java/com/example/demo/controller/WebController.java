package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.entity.Account;
import com.example.demo.entity.User;
import com.example.demo.exception.CustomException;
import com.example.demo.service.AdminService;
import com.example.demo.service.UserService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class WebController {

    @Resource
    private UserService userService;
    @Resource
    private AdminService adminService;

    @PostMapping("/login")
    public Result login(@RequestBody Account account){
        /*User dbUser = userService.login(user);*/
        Map<String, Object> data = null;
        if("USER".equals(account.getRole())){
            data = userService.login(account);
        }else if("ADMIN".equals(account.getRole())){
            data = adminService.login(account);
        }
        return Result.success(data);
    }

    @PostMapping("/register")
    public Result register(@RequestBody User user){
        userService.register(user);
        return Result.success();
    }

    @PostMapping("/updatePassword")
    public Result updatePassword(@RequestBody Account account) {
        if("USER".equals(account.getRole())){
            userService.updatePassword(account);
        }
        if("ADMIN".equals(account.getRole())){
            adminService.updatePassword(account);
        }
        return Result.success();
    }
}
