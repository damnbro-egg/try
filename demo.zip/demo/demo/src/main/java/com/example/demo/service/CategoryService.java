package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.enums.Constants;
import com.example.demo.common.enums.ResultCodeEnum;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Category;
import com.example.demo.exception.CustomException;
import com.example.demo.mapper.CategoryMapper;
import com.example.demo.utils.JwtUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Validated
public class CategoryService {
    @Resource
    private CategoryMapper categoryMapper;

    public void add(Category category) {
        categoryMapper.insert(category);
    }

    public void deleteById(Integer id) {
        categoryMapper.deleteById(id);
    }

    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    public void updateById(Category category) {
        categoryMapper.updateById(category);
    }

    public Category selectById(Integer id) {
        return categoryMapper.selectById(id);
    }

    public List<Category> selectAll(Category category) {
        return categoryMapper.selectAll(category);
    }

    public IPage<Category> selectPage(Category category, Integer pageNum, Integer pageSize) {
        Page<Category> page = new Page(pageNum,pageSize);
        return categoryMapper.selectPage(page, category);
    }
}
