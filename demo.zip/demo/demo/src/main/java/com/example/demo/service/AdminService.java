package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.enums.Constants;
import com.example.demo.common.enums.ResultCodeEnum;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Admin;
import com.example.demo.exception.CustomException;
import com.example.demo.mapper.AdminMapper;
import com.example.demo.utils.JwtUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Validated
public class AdminService {
    @Resource
    private AdminMapper adminMapper;

    public Map<String, Object> login(Account account) {
            String username = account.getUsername();
            Admin dbAdmin = adminMapper.selectByUsername(username);
            if (dbAdmin == null) {
                throw new CustomException("500", "账号不存在");
            }
            String password = account.getPassword();
            if (!dbAdmin.getPassword().equals(password)) {
                throw new CustomException("500", "账号或密码错误");
            }
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", dbAdmin.getId());
            claims.put("username", dbAdmin.getUsername());
            claims.put("role",dbAdmin.getRole());
            String token = JwtUtil.genToken(claims);
            Map<String, Object> data = new HashMap<>();
            data.put("token", token);
            data.put("admin", dbAdmin);
            return data;
    }

    public void add(Admin admin) {
        //1,account
         Admin dbAdmin = adminMapper.selectByUsername(admin.getUsername());
        if(dbAdmin != null){
            throw new CustomException(ResultCodeEnum.USER_EXIST_ERROR);
        }
        //2.mima
        if(ObjectUtils.isEmpty(admin.getPassword())){
            admin.setPassword(Constants.USER_DEFAULT_PASSWORD.getValue());
        }
        //3.name
        if(ObjectUtils.isEmpty(admin.getName())){
            admin.setName(admin.getUsername());
        }
        //4.role
        admin.setRole(RoleEnum.ADMIN.name());
        adminMapper.insert(admin);
    }

    public void deleteById(Integer id) {
        adminMapper.deleteById(id);
    }

    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    public void updateById(Admin admin) {
        adminMapper.updateById(admin);
    }

    public Admin selectById(Integer id) {
        return adminMapper.selectById(id);
    }

    public List<Admin> selectAll(Admin admin) {
        return adminMapper.selectAll(admin);
    }

    public IPage<Admin> selectPage(Admin admin, Integer pageNum, Integer pageSize) {
        /*QueryWrapper<Admin> queryWrapper = new QueryWrapper<Admin>();*/
        Page<Admin> page = new Page(pageNum,pageSize);
        return adminMapper.selectPage(page, admin);
    }

    public void register(@Valid Admin admin) {
        //1.account
        Admin dbAdmin = adminMapper.selectByUsername(admin.getUsername());
        if(dbAdmin != null){
            throw new CustomException(ResultCodeEnum.USER_EXIST_ERROR);
        }
        //2.mima
        if(ObjectUtils.isEmpty(admin.getPassword())){
            admin.setPassword(Constants.USER_DEFAULT_PASSWORD.getValue());
        }
        //3.name
        if(ObjectUtils.isEmpty(admin.getName())){
            admin.setName(admin.getUsername());
        }
        //4.role
        admin.setRole(RoleEnum.USER.name());

        adminMapper.insert(admin);
    }

    public void updatePassword(Account account) {
        if(!account.getNewpassword1().equals(account.getNewpassword2())){
            throw new CustomException("50001","您两次输入的密码不一致");
        }
    }
}
