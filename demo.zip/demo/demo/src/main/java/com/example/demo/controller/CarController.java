package com.example.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.entity.Car;
import com.example.demo.mapper.CarMapper;
import com.example.demo.service.CarService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.common.Result;
import java.util.List;

@RestController
@RequestMapping("/car")
public class CarController {

    @Resource
    private CarService carService;

    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id){
        Car car = carService.selectById(id);
        return Result.success(car);
    }

    @GetMapping("/selectAll")
    public Result selectAll(Car car){
        List<Car> list = carService.selectAll(car);
        return Result.success(list);
    }

    @GetMapping(value="/selectPage", produces = "application/json;charset=UTF-8")
    public Result selectPage(
            Car car,
            @RequestParam(value="page" ,defaultValue = "1") int pageNum,
            @RequestParam(value="size" ,defaultValue = "12") int pageSize){
            IPage<Car> page = carService.selectPage(car ,pageNum ,pageSize);
            return Result.success(page);
    }

}
