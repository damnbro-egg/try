package com.example.demo.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.common.enums.RoleEnum;
import com.example.demo.entity.Account;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Comment;
import com.example.demo.mapper.CommentMapper;
import com.example.demo.service.CommentService;
import com.example.demo.service.UserService;
import com.example.demo.utils.JwtUtil;
import com.example.demo.vo.params.CommentParam;
import com.example.demo.vo.params.CommentVo;
import com.example.demo.vo.params.UserVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

import static cn.hutool.extra.cglib.CglibUtil.copyList;

@Service
public class CommentServiceImpl implements CommentService {
    @Autowired
    private CommentMapper commentMapper;
    @Autowired
    private UserService userService;

    @Override
    public List<CommentVo> commentByArticleId(Integer authorId) {
        Comment com1=new Comment();
        com1.setArticleId(authorId);
        com1.setLevel(1);
        List<Comment> comments = commentMapper.selectAll(com1);
        List<CommentVo> commentVoList = copyList(comments);
        return commentVoList;
    }

    @Override
    public void comment(CommentParam commentParam){
        Account currentUser = JwtUtil.getCurrentUser();
        Comment comment = new Comment();
        comment.setArticleId(commentParam.getArticleId());
        comment.setAuthorId(currentUser.getId());
        comment.setContent(commentParam.getContent());
        comment.setCreateDate(System.currentTimeMillis());
        Integer parent = commentParam.getParent();
        if(parent == null || parent == 0){
            comment.setLevel(1);
        }else{
            comment.setLevel(2);
        }
        comment.setParentId(parent == null ? 0 : parent);
        Integer toUserId = commentParam.getToUserId();
        comment.setToUid(toUserId == null ? 0 : toUserId);
        commentMapper.insert(comment);
        return ;
    }

    @Override
    public void add(Comment comment) {
        comment.setCreateDate(System.currentTimeMillis());
        Account currentUser = JwtUtil.getCurrentUser();
        comment.setAuthorId(currentUser.getId());
        commentMapper.insert(comment);
    }

    @Override
    public void deleteById(Integer id) {
        commentMapper.deleteById(id);
    }

    @Override
    public void deleteBatch( List<Integer> ids){
        for(Integer id : ids){
            this.deleteById(id);
        }
    }

    @Override
    public void updateById(Comment comment) {
        commentMapper.updateById(comment);
    }

    @Override
    public List<Comment> selectByAuthorId(Integer authorId){return commentMapper.selectByAuthorId(authorId);}

    @Override
    public List<Comment> selectAll(Comment comment) {
        return commentMapper.selectAll(comment);
    }

    @Override
    public List<Comment> selectByName(String name) {
        return commentMapper.selectByName(name);
    }

    @Override
    public IPage<Comment> selectPage(Comment comment, Integer pageNum, Integer pageSize) {
        Page<Comment> page = new Page(pageNum,pageSize);
        return commentMapper.selectPage(page, comment);
    }

    private List<CommentVo> copyList(List<Comment> comments){
        List<CommentVo> commentVoList = new ArrayList<>();
        for(Comment comment:comments){
            commentVoList.add(copy(comment));
        }
        return commentVoList;
    }

    private CommentVo copy(Comment comment){
        CommentVo commentVo = new CommentVo();
        BeanUtils.copyProperties(comment,commentVo);
        Integer authorId = comment.getAuthorId();
        commentVo.setCreateDate(new DateTime(comment.getCreateDate()).toString("yyyy-MM-dd HH:mm"));
        UserVo userVo = userService.selectUserVoById(authorId);
        commentVo.setAuthor(userVo);
        Integer level = comment.getLevel();
        if(level == 1){
            Integer id = comment.getId();
            List<CommentVo> commentVoList = selectCommentsByParentId(id);
            commentVo.setChildrens(commentVoList);
        }
        if(level > 1){
            Integer toUid = comment.getToUid();
            UserVo toUserVo = userService.selectUserVoById(toUid);
            commentVo.setToUser(toUserVo);
        }
        return commentVo;
    }

    private List<CommentVo> selectCommentsByParentId(Integer id){
        Comment com2=new Comment();
        com2.setParentId(id);
        com2.setLevel(2);
        return copyList(commentMapper.selectAll(com2));
    }
}
