package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.entity.Blog;
import com.example.demo.entity.Comment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommentMapper {
    void insert(Comment comment);

    void updateById(Comment comment);

    void deleteById(Integer id);

    List<Comment> selectByAuthorId(Integer authorId);

    List<Comment> selectByName(String name);

    List<Comment> selectAll(@Param("comment")Comment comment);

    IPage<Comment> selectPage(Page<Comment> page, @Param("comment")Comment comment);
}
